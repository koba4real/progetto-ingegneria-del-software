package barattoController;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import barattoModel.Accesso;
import barattoModel.Categoria;
import barattoModel.Fruitore;
import barattoModel.GestioneGerarchie;
import barattoModel.ListaOfferteAccoppiate;
import barattoModel.Offerta;
import barattoModel.OfferteAccoppiate;
import barattoModel.ParametriDiScambio;
import barattoModel.StatoOfferta;
import barattoView.IOFruitore;
import barattoView.IOGeneric;
import barattoView.InputDati;
import barattoView.MyMenu;

public class MenuGestioneOfferte {

	private static final String APRI = "apri";
	private static final String RITIRA = "ritira";
	private static final String ACCETTARE_O_RIFIUTARE_APPUNTAMENTO = "vuoi accettare questo appuntamento?";
	private static final String TITOLO_MENU = "Menu Gestione Offerte ";
	private static final String[] VOCI = { "Ritira un Offerta", 
										   "Riapri un Offerta ritirata",
										   "Visualizza le Offerte aperte relative ad una categoria", 
										   "Effettua Baratto",
										   "Proposte di Baratto",
										   "Gestisci appuntamenti",
										   "Visualizza le tue Offerte",
										   "Visualizza l'ultima risposta per le offerte in scambio"};
	
	public static Fruitore printMenuGestioneOfferte(Fruitore fruitore) {
		MyMenu menu1 = new MyMenu(TITOLO_MENU ,VOCI);
		int scelta;
		do {
			scelta= menu1.scegli();
			switch(scelta) {
			case 1:
				Offerta offerta = IOFruitore.sceltaOffertaAperta(fruitore);
				if(offerta==null)
					break;
				int index = fruitore.getOfferte().indexOf(offerta);
				fruitore.getOfferte().get(index).setStatoOfferta(StatoOfferta.APERTA.next(RITIRA));
				IOFruitore.msgRitiroOfferta();
				break;
			case 2:
				offerta = IOFruitore.sceltaOffertaRitirata(fruitore);
				if(offerta==null)
					break;
				index = fruitore.getOfferte().indexOf(offerta);
				fruitore.getOfferte().get(index).setStatoOfferta(StatoOfferta.RITIRATA.next(APRI));
				IOFruitore.msgRiapriOfferta();
				break;
			case 3:
				printOffAperte();
				break;
			case 4:		
				if(ParametriDiScambio.getPiazza()==null) {
					IOFruitore.msgParamNonFix();
					break;
				}	
				Offerta offertaAccoppiata = IOFruitore.sceltaOffertaDaProporre(fruitore);
				if(offertaAccoppiata == null)
					break;
				ArrayList<Offerta> offerteAperte = Accesso.offerteDaScambiare(offertaAccoppiata);
				Offerta offertaSelezionata = IOFruitore.sceltaOffertaDaScambiare(offerteAperte);
				if(offertaSelezionata==null)
					break;
				index = fruitore.getOfferte().indexOf(offertaAccoppiata);
				accoppiaOfferte(fruitore, index, offertaAccoppiata, offertaSelezionata);
				break;
			case 5 :
				ArrayList<OfferteAccoppiate> listaProposte = fruitore.getListaProposte();
				if(listaProposte.isEmpty()) {
					IOFruitore.msgNoProposte();
					break;
				}
				OfferteAccoppiate offerteAccoppiate = IOFruitore.sceltaOffertaProposta(listaProposte);
				if(offerteAccoppiate==null)
					break;
				offerteAccoppiate = IOFruitore.leggiDatiScambio(offerteAccoppiate, ParametriDiScambio.getLuoghi());
				ListaOfferteAccoppiate.setLastFruitoreById(offerteAccoppiate.getOffertaAccoppiata().getCoodiceID(), fruitore.getUsername());
				offertaAccoppiata = setStatoOfferte(fruitore, offerteAccoppiate);
				ListaOfferteAccoppiate.setDataScadenzaOff(offertaAccoppiata.getCoodiceID());
				
				break;
			case 6 : 
				OfferteAccoppiate off = IOFruitore.sceltaOffertaAppuntamento(fruitore);
				if( off == null)
					break;
				if(InputDati.yesOrNo(ACCETTARE_O_RIFIUTARE_APPUNTAMENTO)) {
					chiudiOfferta(fruitore, off);
				}
				else {
					fissaAltroAppuntamento(fruitore, off);
				}
				break;
			case 7 :
				IOFruitore.visOfferte(fruitore.getOfferte());
				break;
			case 8:
				IOFruitore.visRisposte(fruitore);
				break;
			case 0:
				break;
			}
			
		}while(scelta!=0);
		return fruitore;
	}
	private static void fissaAltroAppuntamento(Fruitore fruitore, OfferteAccoppiate off) {
		IOFruitore.msgAltroAppuntamento();
		IOFruitore.leggiDatiScambio(ListaOfferteAccoppiate.getOfferteById(off.getOffertaAccoppiata().getCoodiceID()), ParametriDiScambio.getLuoghi());
		ListaOfferteAccoppiate.setLastFruitoreById( off.getOffertaAccoppiata().getCoodiceID(), fruitore.getUsername());
		ListaOfferteAccoppiate.setDataScadenzaOff(off.getOffertaAccoppiata().getCoodiceID());
		ListaOfferteAccoppiate.setDataScadenzaOff(off.getOffertaSelezionata().getCoodiceID());
	}
	private static void chiudiOfferta(Fruitore fruitore, OfferteAccoppiate off) {
		ListaOfferteAccoppiate.chiudiStatoById(off.getOffertaAccoppiata().getCoodiceID());
		fruitore.setStatoOfferta(off.getOffertaAccoppiata().getCoodiceID(), StatoOfferta.CHIUSA);
		fruitore.setStatoOfferta(off.getOffertaSelezionata().getCoodiceID(), StatoOfferta.CHIUSA);
		ListaOfferteAccoppiate.eliminaOfferte(off);
		IOFruitore.msgOffChiusa();
	}
	private static void accoppiaOfferte(Fruitore fruitore, int index, Offerta offertaAccoppiata, Offerta offertaSelezionata) {
		fruitore.getOfferte().get(index).setStatoOfferta(StatoOfferta.ACCOPPIATA);
		fruitore.getOfferte().get(index).setDataDiAccoppiamento(new Date(System.currentTimeMillis()));
		index = Accesso.getFruitori().getFruitore(offertaSelezionata.getAutoreOfferta()).getOfferte().indexOf(offertaSelezionata);
		Accesso.getFruitori().getFruitore(offertaSelezionata.getAutoreOfferta()).getOfferte().get(index).setStatoOfferta(StatoOfferta.SELEZIONATA);
		Accesso.getFruitori().getFruitore(offertaSelezionata.getAutoreOfferta()).getOfferte().get(index).setDataDiAccoppiamento(new Date(System.currentTimeMillis()));;
		OfferteAccoppiate offAccoppiate = new OfferteAccoppiate(offertaAccoppiata, offertaSelezionata);
		ListaOfferteAccoppiate.addOfferteAccoppiate(offAccoppiate);
		
	}
	public static Offerta setStatoOfferte(Fruitore fruitore, OfferteAccoppiate offerteAccoppiate) {
		Offerta offertaAccoppiata = offerteAccoppiate.getOffertaAccoppiata();
		Offerta offertaSelezionata = offerteAccoppiate.getOffertaSelezionata();
		int index = fruitore.getOfferte().indexOf(offertaSelezionata);
		fruitore.getOfferte().get(index).setStatoOfferta(StatoOfferta.IN_SCAMBIO);
		index = Accesso.getFruitori().getFruitore(offertaAccoppiata.getAutoreOfferta()).getOfferte().indexOf(offertaAccoppiata);
		Accesso.getFruitori().getFruitore(offertaAccoppiata.getAutoreOfferta()).getOfferte().get(index).setStatoOfferta(StatoOfferta.IN_SCAMBIO);
		return offertaAccoppiata;
	}
	private static void printOffAperte() {
		ArrayList<Offerta> offerteAperte = new ArrayList<>();	
		Categoria categ = IOGeneric.sceltaFoglia(GestioneGerarchie.getLeaves());
		offerteAperte= Accesso.offerteAperte(categ);
		IOGeneric.visOfferteAperte(offerteAperte);
	}
}
