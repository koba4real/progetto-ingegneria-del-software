package barattoView;

import java.util.ArrayList;


import barattoModel.Categoria;
import barattoModel.Offerta;
import treeNodePackage.TreeNode;

public class IOGeneric {
	private static final String INSERISCI_PASSWORD = "inserisca la sua password: ";
	private static final String INSERISCA_NOME_UTENTE = "\ninserisca il suo nome utente: ";
	private static final String TITOLO= "\n\tBENVENUTO NELL APP DI BARATTO\n";
	private static final String STRINGA_CONF = "\nHai utilizzato le credenziali provvisorie!";
	private static final String STRINGA_REGISTRAZIONE = "\nBenvenuto nell'area di registrazione, "
															+ "\nscegli le tue credenziali personali che utilizzerai negli accessi successivi:";
	public static String nomeUser() {
		return InputDati.leggiStringaNonVuota(INSERISCA_NOME_UTENTE);
	}
	public static String passUser() {
		return  InputDati.leggiStringaNonVuota(INSERISCI_PASSWORD);
	}
	
	public static Categoria sceltaFoglia(ArrayList<TreeNode<Categoria>> listaFoglie) {
		if(listaFoglie == null || listaFoglie.isEmpty()) {
			System.out.println("Non sono ancora state create categorie");
			return null;
		}
		System.out.println("\nScegli una categoria: ");
		for(int i=0; i< listaFoglie.size(); i++) {
			System.out.println(i+1 +") Nome: " + listaFoglie.get(i).data.getNome() + "  Descrizione: "+ listaFoglie.get(i).data.getDescrizione());
		}
		
		int scelta = InputDati.leggiIntero("Digita un numero: ", 1 , listaFoglie.size());
		
		return listaFoglie.get(scelta-1).data.getCopy();
	}
	
	public static void visAlbero(TreeNode<Categoria> nodo) {
		for (TreeNode<Categoria> node : nodo.getTreeRoot()) {
			String indent = createIndent(node.getLevel());
			IOGeneric.stampaString(indent + node.data + "\t" + node.data.getCampi());
		}
	}
	
	private static String createIndent(int depth) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < depth; i++) {
			sb.append(' ');
		}
		return sb.toString();
	}
	
	
	public static void visOfferteAperte(ArrayList<Offerta> offerte) {
		if(offerte == null || offerte.isEmpty()) {
			System.out.println("Non ci sono offerte aperte riguardo questa categoria!");
			return;
		}
		for(Offerta off: offerte) {
			System.out.println(off.toString());
		}
	}
	public static void visOfferteInScambioEChiuse(ArrayList<Offerta> offerte) {
		if(offerte == null || offerte.isEmpty()) {
			System.out.println("Non ci sono offerte in scambio o chiuse riguardo questa categoria!");
			return;
		}
		for(Offerta off: offerte) {
			System.out.println(off.toString());
		}
	}
	public static void stampaString(String txt) {
		System.out.println(txt);
	}
	public static void printTitolo() {
		System.out.println(TITOLO);
	}
	public static void printArrivederci() {
		System.out.println("ARRIVEDERCI");
	}	
	public static void printBenvenuto() {
		System.out.println("BENVENUTO");
	}
	public static void printSaved() {
		System.out.println("Salvataggio effettuato!");
	}
	public static void msgCredNotExist() {
		System.out.println("Credenziali non esistenti!");
	}
	public static void msgPassLong() {
		System.out.println("ATTENZIONE! \nla password supera il numero massimo di caratteri!");
	}
	public static void msgNameLong() {
		System.out.println("ATTENZIONE! \nil username supera il numero massimo di caratteri!");	
	}
	public static void msgUserExist() {
		System.out.println("ATTENZIONE! \nusername gi� esistente!");
	}
	public static void msgCredProvvis() {
		System.out.println(STRINGA_CONF);
	}
	public static void msgDatiInputCaricati() {
		System.out.println("Dati caricati correttamente!");
	}
	public static void msgRegistrazione() {
		System.out.println(STRINGA_REGISTRAZIONE);
	}
	public static void msgErorInputDati() {
		System.out.println("non � stato possibile effettuare il caricamento in quanto non ci sono File Input!");
	}
	
}
