package progetto_IG_baratto;

import java.io.Serializable;
import java.util.ArrayList;

public class Fruitore implements Serializable{
	private String username ;
	private String password;
	private ArrayList<Offerta> offerte = new ArrayList<Offerta>();
	private ArrayList<Offerta> offerteNonPubliche = new ArrayList<Offerta>();
	
	public Fruitore() {}
	
	public Fruitore(String username, String password) {
		this.username = username;
		this.password = password;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void addOfferta(Offerta offerta) {
		this.offerte.add(offerta);
	}
	public ArrayList<Offerta> getOfferte() {
		return offerte;
	}
	public ArrayList<Offerta> getOfferteNonPubliche() {
		return offerteNonPubliche;
	}
	public void setOfferteNonPubliche(ArrayList<Offerta> offerteNonPubliche) {
		this.offerteNonPubliche = offerteNonPubliche;
	}
	public void addOffertaNonP(Offerta offerta) {
		this.offerteNonPubliche.add(offerta);
	}
	public void removeOffertaNonP(Offerta offerta) {
		int index = this.offerteNonPubliche.indexOf(offerta);
		this.offerteNonPubliche.remove(index);
	}
	public void setStatoOfferta(int id, StatoOfferta newStato) {	//modifica lo stato attraverso il ID
		for(Offerta offerta: offerte) {
			if(offerta.getCoodiceID()==id)
				offerta.setStatoOfferta(newStato);
		}
	}
	public void setStatoOfferteScadute() {
		ArrayList<Integer> idOfferte = ListaOfferteAccoppiate.offerteScadute();
		for(Offerta off: this.offerte) {
			if(idOfferte.contains(off.getCoodiceID()))
				off.setStatoOfferta(StatoOfferta.APERTA);
		}
	}
	public void setStatoOfferteChiuse() {	
		for(Offerta off: this.offerte) {
			for(OfferteAccoppiate offerte : ListaOfferteAccoppiate.getListaOfferteAccoppiate() ) {
				int id = off.getCoodiceID();
				if(id == offerte.getOffertaAccoppiata().getCoodiceID() && offerte.getOffertaAccoppiata().getStatoOfferta().equals(StatoOfferta.CHIUSA) )
					off.setStatoOfferta(StatoOfferta.CHIUSA);
				if( id == offerte.getOffertaSelezionata().getCoodiceID() && offerte.getOffertaSelezionata().getStatoOfferta().equals(StatoOfferta.CHIUSA) )
					off.setStatoOfferta(StatoOfferta.CHIUSA);
			}
		}
	}
	
	
	


}
