package progetto_IG_baratto;
import utility.MyMenu;

public class MenuFruitore {
	
	private static final String TITOLO_MENU = "Menu Fruitore";
	private static final String[] VOCI = {"Visualizza le categorie radici e i parametri di scambio"};
	
	
	public static void printMenu() {
		MyMenu menu1 = new MyMenu(TITOLO_MENU ,VOCI);
		int scelta;
		do {
			scelta= menu1.scegli();
			switch(scelta) {
			case 1:
				IOFruitore.visRoots();
				IOFruitore.visParametriDiScambio();
				break;
			case 0:
				break;
			}
			
		}while(scelta!=0);
	}
	
}
