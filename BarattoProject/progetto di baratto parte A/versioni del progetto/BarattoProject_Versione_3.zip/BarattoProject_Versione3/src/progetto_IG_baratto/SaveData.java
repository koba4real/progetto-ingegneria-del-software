package progetto_IG_baratto;

import java.io.File;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

import TreeNodeProject.TreeNode;

public class SaveData {
	
	private static ObjectMapper mapper = new ObjectMapper();
	private static File fileCredenzialiConf = new File("credenzialiConfiguratori.json");
	private static File fileCredenzialiFrui = new File("credenzialiFruitori.json");
	private static File fileGerarchie = new File("dataGerarchie.json");
	private static File fileParametriDiScambio = new File("dataParametri.json");
	
	
	public static void save() {
		String listaConfiguratori = ObjectSerializer.serialize(Accesso.getConfiguratori().getGruppo());
		String listaFruitori = ObjectSerializer.serialize( Accesso.getFruitori().getGruppo());
		String listaGerarchieString = ObjectSerializer.serialize(GestioneGerarchie.getListaDiGerarchie());
		String parametriString = ObjectSerializer.serialize(ParametriDiScambio.getParamToSave());
		
		try{	
			mapper.writeValue(fileCredenzialiConf, listaConfiguratori);
			mapper.writeValue(fileCredenzialiFrui, listaFruitori);
			mapper.writeValue(fileGerarchie, listaGerarchieString);
			mapper.writeValue(fileParametriDiScambio, parametriString);
			
		}catch ( IOException e ) {
			e.printStackTrace();
		}
		IOGeneric.printSaved();
	}
	public static void load_mapp(){
			
		try{
			String stringConf = mapper.readValue(fileCredenzialiConf,String.class);
			
			if(stringConf!=null) {
				HashMap<String , Configuratore> listaConfiguratori = (HashMap<String , Configuratore>)  ObjectSerializer.deserialize(stringConf);
				Accesso.setGruppoConf(listaConfiguratori);	
			}		
		}catch(FileNotFoundException ex){}
		catch(IOException e) {
			e.printStackTrace();
		}	
			
		try {
			String StringFruitori = mapper.readValue(fileCredenzialiFrui, String.class);	
			
			if(StringFruitori!=null) {
				HashMap<String , Fruitore> listaFruitori = (HashMap<String , Fruitore>)  ObjectSerializer.deserialize(StringFruitori);
				Accesso.setGruppoFruitore(listaFruitori);	
			}				
		}catch(FileNotFoundException ex) {}
		catch(IOException e) {
			e.printStackTrace();
		}	
		
		try {
			String stringGerarchie = mapper.readValue(fileGerarchie, String.class);
			if( stringGerarchie!=null ) {
				ArrayList<TreeNode<Categoria>> gerarchie = (ArrayList<TreeNode<Categoria>>) ObjectSerializer.deserialize(stringGerarchie);	
				GestioneGerarchie.setListaDiGerarchie(gerarchie);					
				GestioneGerarchie.setLisataNomi();
			}				
		}catch(FileNotFoundException ex) {}
		catch(IOException e) {
			e.printStackTrace();
		}	
				
		try {	
			String parametriString = mapper.readValue(fileParametriDiScambio, String.class);	
			if(parametriString != null) {
				ArrayList<Object> parametri = (ArrayList<Object>) ObjectSerializer.deserialize(parametriString);
				ParametriDiScambio.setParamSaved(parametri);
			}	
		}catch(FileNotFoundException ex) {}
		catch(IOException e) {
			e.printStackTrace();
		}
	}

}
