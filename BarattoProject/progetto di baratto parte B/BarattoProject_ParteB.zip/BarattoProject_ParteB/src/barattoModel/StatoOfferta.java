package barattoModel;

public enum StatoOfferta {
	
	APERTA("aperta"){
		@Override
		public StatoOfferta next(String scelta) {
			switch(scelta) {
				case "ritira":
					return RITIRATA;
				case "accoppia":
					return ACCOPPIATA;					
				case "seleziona":
					return SELEZIONATA;			
				default:
					return APERTA;
			}
		}
	},
	RITIRATA("ritirata"){
		@Override
		public StatoOfferta next(String scelta) {
			if(scelta.equals("apri"))
				return APERTA;
		return RITIRATA;
		}
	},
	ACCOPPIATA("accoppiata"){
		@Override
		public StatoOfferta next(String scelta) {
			switch(scelta) {
			case "apri":
				return APERTA;
			case "scambia":
				return IN_SCAMBIO;
			default:
				return ACCOPPIATA;
			}
		}
	},
	SELEZIONATA("selezionata"){
		@Override
		public StatoOfferta next(String scelta) {
			switch(scelta) {
			case "apri":
				return APERTA;
			case "scambia":
				return IN_SCAMBIO;
			default:
				return SELEZIONATA;
			}
		}
	},
	IN_SCAMBIO("in scambio"){
		@Override
		public StatoOfferta next(String scelta) {
			switch(scelta) {
			case "apri":
				return APERTA; 
			case "chiudi":
				return CHIUSA;
			default:
				return IN_SCAMBIO;
			}
		}
	},
	CHIUSA("chiusa"){
		@Override
		public StatoOfferta next(String scelta) {
			return CHIUSA;
		}
	};

	private String stato;
	
	StatoOfferta (String stato) {
		this.stato=stato;
	}
	
	public abstract StatoOfferta next(String scelta);
	public String getStato() {
		return this.stato;
	}

}
