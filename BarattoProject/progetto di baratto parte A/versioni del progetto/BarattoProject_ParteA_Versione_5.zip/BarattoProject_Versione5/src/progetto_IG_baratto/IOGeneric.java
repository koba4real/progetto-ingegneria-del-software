package progetto_IG_baratto;

import java.util.ArrayList;

import TreeNodeProject.TreeNode;
import utility.InputDati;

public class IOGeneric {
	private static final String TITOLO= "\n\tBENVENUTO NELL APP DI BARATTO\n";
	private static final String STRINGA_CONF = "\nHai utilizzato le credenziali provvisorie!";
	private static final String STRINGA_REGISTRAZIONE = "\nBenvenuto nell'area di registrazione, "
															+ "\nscegli le tue credenziali personali che utilizzerai negli accessi successivi:";
	
	public static Categoria sceltaFoglia() {
		if(GestioneGerarchie.getLeaves() == null || GestioneGerarchie.getLeaves().isEmpty()) {
			System.out.println("Non sono ancora state create categorie");
			return null;
		}
		System.out.println("\nScegli una categoria: ");
		ArrayList<TreeNode<Categoria>> listaFoglie = GestioneGerarchie.getLeaves();
		for(int i=0; i< listaFoglie.size(); i++) {
			System.out.println(i+1 +") Nome: " + listaFoglie.get(i).data.getNome() + "  Descrizione: "+ listaFoglie.get(i).data.getDescrizione());
		}
		
		int scelta = InputDati.leggiIntero("Digita un numero: ", 1 , listaFoglie.size());
		
		return listaFoglie.get(scelta-1).data.getCopy();
	}
	public static void visOfferteAperte(ArrayList<Offerta> offerte) {
		if(offerte == null || offerte.isEmpty()) {
			System.out.println("Non ci sono offerte aperte riguardo questa categoria!");
			return;
		}
		for(Offerta off: offerte) {
			System.out.println(off.toString());
		}
	}
	public static void visOfferteInScambioEChiuse(ArrayList<Offerta> offerte) {
		if(offerte == null || offerte.isEmpty()) {
			System.out.println("Non ci sono offerte in scambio o chiuse riguardo questa categoria!");
			return;
		}
		for(Offerta off: offerte) {
			System.out.println(off.toString());
		}
	}
	public static void stampaString(String txt) {
		System.out.println(txt);
	}
	public static void printTitolo() {
		System.out.println(TITOLO);
	}
	public static void printArrivederci() {
		System.out.println("ARRIVEDERCI");
	}	
	public static void printBenvenuto() {
		System.out.println("BENVENUTO");
	}
	public static void printSaved() {
		System.out.println("Salvataggio effettuato!");
	}
	public static void msgCredNotExist() {
		System.out.println("Credenziali non esistenti!");
	}
	public static void msgPassLong() {
		System.out.println("ATTENZIONE! \nla password supera il numero massimo di caratteri!");
	}
	public static void msgNameLong() {
		System.out.println("ATTENZIONE! \nil username supera il numero massimo di caratteri!");	
	}
	public static void msgUserExist() {
		System.out.println("ATTENZIONE! \nusername gi� esistente!");
	}
	public static void msgCredProvvis() {
		System.out.println(STRINGA_CONF);
	}
	public static void msgRegistrazione() {
		System.out.println(STRINGA_REGISTRAZIONE);
	}
	public static void msgErorInputDati() {
		System.out.println("non � stato possibile caricare in quanto non ci sono File Input!");
	}
	
}
