package barattoModel;

public abstract class Utente {
	
	protected String username ;
	protected String password;

	public abstract String getUsername();
	public abstract void setUsername(String username);
	public abstract String getPassword();
	public abstract void setPassword(String password);
	

}
