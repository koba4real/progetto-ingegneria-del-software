package progetto_IG_baratto;

import java.util.ArrayList;

import TreeNodeProject.*;
import utility.MyMenu;

public class MenuConfiguratore {
	
	private static final String TITOLO_MENU= "Menu Configuratori";
	private static final String[] VOCI1= { "Inserisci una nuova gerarchia  ", 
											"visualizza gerarchie", 
											"Fissa il valore dei parametri di scambio",
											"Visualizza le Offerte aperte relative ad una categoria"};
	private static final String[] VOCI2= { "Inserisci una sottocategoria", "Torna alla categoria padre", "Visualizza albero"};/// aggiungi visualizzazione del nodo in cui sei 
	
	public static void menuPrincipale() {
		MyMenu menu1 = new MyMenu(TITOLO_MENU ,VOCI1);
		int scelta ;
		do {
			scelta= menu1.scegli();
			switch(scelta) {
			case 1:
				TreeNode<Categoria> rootCat = new TreeNode<>(IOConfiguratore.readCategoriaRadice());
				rootCat = menuCategorie(rootCat);
				GestioneGerarchie.addRoot(rootCat);
				break;
			case 2:	//visualizza gerarchie
				if(GestioneGerarchie.getListaDiGerarchie().isEmpty())
					IOConfiguratore.listaGerarchieIsEmpty();
				else
					IOConfiguratore.visGerarchie();
				break;
			case 3: //fissa i parametri di scambio
				if(ParametriDiScambio.getPiazza()==null)
					IOConfiguratore.readParametri();
				else
					IOConfiguratore.msgParametriFixed();
				break;
			case 4:
				ArrayList<Offerta> offerteAperte = new ArrayList<>();			
				Categoria cat = IOGeneric.sceltaFoglia();
				Accesso.getFruitori().getGruppo().forEach( (k,v) -> {
					Fruitore f = (Fruitore) v;
					for(Offerta off : f.getOfferte()) {
						if( off.getArticolo().getCategoria().getNome().equalsIgnoreCase(cat.getNome()) && off.isOffertaAperta())
							offerteAperte.add(off);		
					}
				});
				IOGeneric.visOfferteAperte(offerteAperte);
				break;
			case 0:
				break;
			}	
			
		}while(scelta!=0);	
		
	}
	
	private static TreeNode<Categoria> menuCategorie(TreeNode<Categoria> nodo) {
		MyMenu menu2 = new MyMenu("" ,VOCI2);
		int scelta ;
		do {
			String visRoot = "";
			if(nodo.isRoot())
				visRoot=" (Categoria Radice)";
			menu2.setTitolo("Categoria attuale: " + nodo.data.getNome() + visRoot);
			
			scelta= menu2.scegli();
			switch(scelta) {
			case 1://inserisci una sottoCategoria		
				nodo = GestioneAlbero.inserisciSottocategoria(nodo);				
				break;
			case 2://ritorna al nodo padre 
				if( ! nodo.isRoot()) {
					nodo = nodo.parent;
				}
				else
					IOConfiguratore.msgNoParent();;
				break;
			case 3:	//visualizzazione gerarchia
					GestioneAlbero.visAlbero(nodo);
				break;
			case 0: 
				break;
			}
			
		}while(scelta!=0);	
		return nodo.getTreeRoot();
	}
	

}
