package barattoController;

import barattoModel.Articolo;
import barattoModel.Categoria;
import barattoModel.Fruitore;
import barattoModel.GestioneGerarchie;
import barattoModel.Offerta;
import barattoModel.ParametriDiScambio;
import barattoView.IOFruitore;
import barattoView.IOGeneric;
import barattoView.MyMenu;
public class MenuFruitore {
	
	private static final String TITOLO_MENU = "Menu Fruitore";
	private static final String[] VOCI = {"Visualizza le categorie radici e i parametri di scambio",
										  "Crea un articolo", 
										  "Pubblica un articolo",
										  "Gestisci Offerte " };
	
	
	public static Fruitore printMenu(Fruitore fruitore) {
		MyMenu menu1 = new MyMenu(TITOLO_MENU ,VOCI);
		int scelta;
		fruitore.setStatoOfferteScadute();
		fruitore.setStatoOfferteChiuse();
		do {
			scelta= menu1.scegli();
			switch(scelta) {
			
			case 1:
				IOFruitore.visRoots(GestioneGerarchie.getListaDiGerarchie());
				IOFruitore.visParametriDiScambio(ParametriDiScambio.getParamToSave());
				break;
			case 2:
				Categoria cat = IOGeneric.sceltaFoglia(GestioneGerarchie.getLeaves());
				if(cat==null)
					IOFruitore.msgArticolo();
				else {
					Offerta offerta = new Offerta( new Articolo(cat), fruitore.getUsername() );
					offerta.getArticolo().setCampi(IOFruitore.inizializzArt(cat));
					fruitore.addOffertaNonP(offerta);
				}
				break;
			case 3:
				Offerta offerta = IOFruitore.sceltaArticolo(fruitore);
				if(offerta==null)
					break;
				fruitore.addOfferta(offerta);
				fruitore.removeOffertaNonP(offerta);
				IOFruitore.msgPubblicazione();
				break;
			case 4 :
				fruitore = MenuGestioneOfferte.printMenuGestioneOfferte(fruitore);
				break;
			case 0:
				break;
			}
			
		}while(scelta!=0);
		return fruitore;
	}
		
	
}
