package progetto_IG_baratto;
import java.util.ArrayList;

import utility.MyMenu;

public class MenuFruitore {
	
	private static final String TITOLO_MENU = "Menu Fruitore";
	private static final String[] VOCI = {"Visualizza le categorie radici e i parametri di scambio",
										  "Crea un articolo", 
										  "Pubblica un articolo", 
										  "Ritira un Offerta", 
										  "Riapri un Offerta ritirata",
										  "Visualizza le Offerte aperte relative ad una categoria",
										  "Visualizza le tue Offerte"};
	
	
	public static Fruitore printMenu(Fruitore fruitore) {
		MyMenu menu1 = new MyMenu(TITOLO_MENU ,VOCI);
		int scelta;
		do {
			scelta= menu1.scegli();
			switch(scelta) {
			case 1:
				IOFruitore.visRoots();
				IOFruitore.visParametriDiScambio();
				break;
			case 2:
				Categoria cat = IOGeneric.sceltaFoglia();
				if(cat==null)
					IOFruitore.msgArticolo();
				else {
					Articolo articolo = IOFruitore.inizializzArt(cat);
					fruitore.addArticolo(articolo);
				}
				break;
			case 3:
				Articolo articolo = IOFruitore.sceltaArticolo(fruitore);
				if(articolo==null)
					break;
				Offerta offerta = new Offerta(articolo);
				fruitore.addOfferta(offerta);
				fruitore.removeArticolo(articolo);
				IOFruitore.msgPubblicazione();
				break;
			case 4:
				offerta = IOFruitore.sceltaOffertaAperta(fruitore);
				if(offerta==null)
					break;
				int index = fruitore.getOfferte().indexOf(offerta);
				fruitore.getOfferte().get(index).ritiraOfferta();
				IOFruitore.msgRitiroOfferta();
				break;
			case 5:
				offerta = IOFruitore.sceltaOffertaRitirata(fruitore);
				if(offerta==null)
					break;
				index = fruitore.getOfferte().indexOf(offerta);
				fruitore.getOfferte().get(index).apriOfferta();
				IOFruitore.msgRiapriOfferta();
				break;
			case 6:
				ArrayList<Offerta> offerteAperte = new ArrayList<>();			
				cat = IOGeneric.sceltaFoglia();
				Accesso.getFruitori().getGruppo().forEach( (k,v) -> {
					Fruitore f = (Fruitore) v;
					for(Offerta off : f.getOfferte()) {
						if( off.getArticolo().getCategoria().getNome().equalsIgnoreCase(cat.getNome()) && off.isOffertaAperta())
							offerteAperte.add(off);		
					}
				});
				IOGeneric.visOfferteAperte(offerteAperte);
				break;
			case 7:
				IOFruitore.visOfferte(fruitore.getOfferte());
				//lista di offerte generale per tutto il programma, forse anche articoli
				break;
			case 0:
				break;
			}
			
		}while(scelta!=0);
		return fruitore;
	}
	
}
