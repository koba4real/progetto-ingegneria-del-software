package progetto_IG_baratto;

import java.io.Serializable;
import java.util.ArrayList;

public class Categoria implements Serializable{
	
	private String nome;
	private String descrizione;
	private ArrayList<CampoNativo> campi = new ArrayList<CampoNativo>();
	
	public Categoria(String nome, String descrizione) {
		this.nome = nome;
		this.descrizione = descrizione;
	}
	
	public void addCampo(CampoNativo campo) {
		campi.add(campo);
	}
	
	
	public void addCampi(ArrayList<CampoNativo> campo) {
		campi.addAll(campo);
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDescrizione() {
		return descrizione;
	}
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	public ArrayList<CampoNativo> getCampi() {
		return campi;
	}
	public void setCampi(ArrayList<CampoNativo> campiNativi) {
		this.campi = campiNativi;
	}
	
	public String toString() {
		return "Nome: " + this.nome + ";  Descrizione: " +this.descrizione + ";  Campi nativi: "  ;
	}
	
	
	
}
