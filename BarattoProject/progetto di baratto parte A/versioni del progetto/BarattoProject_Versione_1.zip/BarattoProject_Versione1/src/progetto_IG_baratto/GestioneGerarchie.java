package progetto_IG_baratto;

import java.util.ArrayList;

import TreeNodeProject.TreeNode;

public class GestioneGerarchie {
	
	private static ArrayList<TreeNode<Categoria>> listaDiGerarchie = new ArrayList<>();
	
	public static void inizializzaGerarchie() {
		listaDiGerarchie = MenuTree.menuGerarchia(listaDiGerarchie);
	}

	public static ArrayList<TreeNode<Categoria>> getListaDiGerarchie() {
		return listaDiGerarchie;
	}
	
	public static void setListaDiGerarchie(ArrayList<TreeNode<Categoria>> lista) {
		listaDiGerarchie = lista ;
	}
	
	public static void setLisataNomi() {	//modifica la lista dei nomi delle categorie radici 
		ArrayList<String> listaNomi = new ArrayList<String>();
		for(TreeNode<Categoria> nodo: listaDiGerarchie) {
			listaNomi.add( nodo.data.getNome() );
		}
		IOTreeData.setNomiRoot(listaNomi);	
	}
	
	public static void visGerarchie() {
		System.out.println("Gerarchie salvate: \n");
		for(TreeNode<Categoria> albero : listaDiGerarchie) {
			GestioneAlbero.visAlbero(albero);
			System.out.println("\n");
		}
	}
	
	
	
	
	

	
	
}
