package data;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.codehaus.jackson.map.ObjectMapper;

import barattoModel.ListaOfferteAccoppiate;
import barattoModel.OfferteAccoppiate;
import utility.ObjectSerializer;

public class DatiListaOfferteAccoppiate {
	
	private static ObjectMapper mapper = new ObjectMapper();
	
	public static void save(File file) {
		String listaOfferteAccoppiate = ObjectSerializer.serialize(ListaOfferteAccoppiate.getListaOfferteAccoppiate());
		try {
			mapper.writeValue(file, listaOfferteAccoppiate);
			}catch(IOException e) {
			e.printStackTrace();	
		}	
	}

	public static ArrayList<OfferteAccoppiate> importaDaFile(File file){	//controlla in caso sia null
			
			ArrayList<OfferteAccoppiate> offAccoppiate = new ArrayList<>();
			
			try {
				String stringOffAccoppiate = mapper.readValue(file, String.class);
				if( stringOffAccoppiate!=null ) {
					offAccoppiate = (ArrayList<OfferteAccoppiate>) ObjectSerializer.deserialize(stringOffAccoppiate);
				}				
			}catch(FileNotFoundException ex) {
			}
			catch(IOException e) {
				e.printStackTrace();
			}
			return offAccoppiate;
	}
}
