package data;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import org.codehaus.jackson.map.ObjectMapper;

import barattoModel.Accesso;
import barattoModel.Configuratore;
import utility.ObjectSerializer;

public class DatiCredenzialiConfiguratore {
	
	private static ObjectMapper mapper = new ObjectMapper();
	
	public static void save(File file) {
		String listaConfiguratori = ObjectSerializer.serialize(Accesso.getConfiguratori().getGruppo());
		try {
		mapper.writeValue(file, listaConfiguratori);	
		}catch(IOException e) {
			e.printStackTrace();	
		}	
	}
	public static HashMap<String , Configuratore> importaDaFile(File file){	//controlla in caso sia null
		
		HashMap<String , Configuratore> listaConfiguratori = new HashMap<>();
		
		try{
			String stringConf = mapper.readValue(file,String.class);
			
			if(stringConf!=null) {
				listaConfiguratori = (HashMap<String , Configuratore>)  ObjectSerializer.deserialize(stringConf);
			}		
		}catch(FileNotFoundException ex){}
		catch(IOException e) {
			e.printStackTrace();
		}	
		return listaConfiguratori;
	}

}
