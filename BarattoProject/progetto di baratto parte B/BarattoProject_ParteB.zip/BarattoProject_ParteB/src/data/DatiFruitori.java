package data;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import org.codehaus.jackson.map.ObjectMapper;

import barattoModel.Accesso;
import barattoModel.Fruitore;
import utility.ObjectSerializer;

public class DatiFruitori {
	
	private static ObjectMapper mapper = new ObjectMapper();
	
	public static void save(File file) {
		String listaFruitori = ObjectSerializer.serialize( Accesso.getFruitori().getGruppo());
		try {
			mapper.writeValue(file, listaFruitori);
			}catch(IOException e) {
			e.printStackTrace();	
		}	
	}
	public static HashMap<String , Fruitore> importaDaFile(File file){	//controlla in caso sia null
		
		HashMap<String , Fruitore> listaFruitori = new HashMap<>();
		
		try {
			String StringFruitori = mapper.readValue(file, String.class);	
			
			if(StringFruitori!=null) {
				listaFruitori = (HashMap<String , Fruitore>)  ObjectSerializer.deserialize(StringFruitori);	
			}				
		}catch(FileNotFoundException ex) {}
		catch(IOException e) {
			e.printStackTrace();
		}	
		return listaFruitori;
	}

}
