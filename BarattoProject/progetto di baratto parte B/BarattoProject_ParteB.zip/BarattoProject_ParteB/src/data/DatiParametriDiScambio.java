package data;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.codehaus.jackson.map.ObjectMapper;

import barattoModel.ParametriDiScambio;
import utility.ObjectSerializer;

public class DatiParametriDiScambio {

	private static ObjectMapper mapper = new ObjectMapper();
	
	public static void save(File file) {
		String parametriString = ObjectSerializer.serialize(ParametriDiScambio.getParamToSave());
		try {
			mapper.writeValue(file, parametriString);
			}catch(IOException e) {
			e.printStackTrace();	
		}	
	}

	public static ArrayList<Object> importaDaFile(File file){
			
			ArrayList<Object> parametri  = new ArrayList<>();
			
			try {
				String parametriString =  mapper.readValue(file, String.class);
				
				if(parametriString != null) {
					parametri = (ArrayList<Object>) ObjectSerializer.deserialize(parametriString);
				}	
			}catch(FileNotFoundException ex) {}
			catch(IOException e) {
				e.printStackTrace();
			}
			return parametri;
	}

}
