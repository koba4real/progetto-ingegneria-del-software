package barattoModel;

import java.util.HashMap;

public abstract class GruppoUtente {
	
	protected HashMap gruppo;
	
	public final HashMap getGruppo() {
		return gruppo;
	}
	public final void setGruppo(HashMap gruppo) {
		this.gruppo = gruppo;
	}
	public final boolean check_username(String user) {	
		return gruppo.containsKey(user.toLowerCase()); 
	}
	public abstract boolean checkUser(Utente user);
}
