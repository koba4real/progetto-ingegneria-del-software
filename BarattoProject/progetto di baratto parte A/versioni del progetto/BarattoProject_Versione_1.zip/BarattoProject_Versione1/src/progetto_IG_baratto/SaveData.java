package progetto_IG_baratto;

import java.io.File;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;



import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;



import TreeNodeProject.TreeNode;

public class SaveData {
	
	private static ObjectMapper mapper = new ObjectMapper();
	private static File fileAccesso = new File("data.json");
	private static File fileGerarchie = new File("dataGerarchie.json");
	
	
	
	public static void save() {
		
		String listaGerarchieString = ObjectSerializer.serialize(GestioneGerarchie.getListaDiGerarchie());
		
		try{	
			mapper.writeValue(fileAccesso, Accesso.getConfiguratori().getGruppo());
			mapper.writeValue(fileGerarchie, listaGerarchieString);
			
		}catch ( IOException e ) {
			e.printStackTrace();
		}
		System.out.println("Salvataggio effettuato!");
		
	}
	public static void load_mapp(){
		
			try{
				HashMap<String, Configuratore> map = mapper.readValue(fileAccesso, new TypeReference<HashMap<String, Configuratore>>() {});
				String stringGerarchie = mapper.readValue(fileGerarchie, String.class);
				
				if(map!=null) {
					Accesso.setGruppo(map);	
				}
				if( stringGerarchie!=null ) {
					ArrayList<TreeNode<Categoria>> gerarchie = (ArrayList<TreeNode<Categoria>>) ObjectSerializer.deserialize(stringGerarchie);	
					GestioneGerarchie.setListaDiGerarchie(gerarchie);
					GestioneGerarchie.setLisataNomi();
				}
				
				
				
				
			}catch(FileNotFoundException ex) {
			}catch(IOException e) {
				e.printStackTrace();
			}

	}


}
