package progetto_IG_baratto;

import java.io.Serializable;

public class IntervalloOrario implements Serializable{
	private double orarioInizio;
	private double orarioFine;
	
	public IntervalloOrario(double oI, double oF) {
		this.orarioInizio= oI;
		this.orarioFine=oF;
	}
	
	public static boolean checkOrario(double orario) {
		int result = (int)orario;
		if(result<0 || result>=24)
			return false;
		double dec = orario - result;
		if(dec<0 || dec> 0.59)
			return false;
		return true;	
	}
	public double getOrarioInizio() {
		return orarioInizio;
	}
	public void setOrarioInizio(double orarioInizio) {
		this.orarioInizio = orarioInizio;
	}
	public double getOrarioFine() {
		return orarioFine;
	}
	public void setOrarioFine(double orarioFine) {
		this.orarioFine = orarioFine;
	}
	
	public String toString() {
		return String.format("%.2f" , this.orarioInizio) + "-" + String.format("%.2f" , this.orarioFine);
	}
	
	

}
