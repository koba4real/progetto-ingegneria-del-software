package barattoModel;

import java.util.HashMap;

public class GruppoConf extends GruppoUtente{
	
	public GruppoConf() {
		this.gruppo = new HashMap<String , Configuratore>() ;
	}
	
	public void aggiungiConf(Configuratore conf) {
		String s = conf.getUsername();
		gruppo.put(s.toLowerCase(), conf);
	}
		
	public boolean checkUser(Utente user) {	 //true se esiste gi� il configuratore
		if( ! check_username(user.getUsername()))
			return false;
		String u = user.getUsername();
		String p = user.getPassword();
		Configuratore c = (Configuratore)gruppo.get(u);
		return  c.getPassword().equals(p);
	}

	

	
}
