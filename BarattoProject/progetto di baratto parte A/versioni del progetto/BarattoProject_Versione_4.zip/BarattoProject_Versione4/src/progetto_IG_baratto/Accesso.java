package progetto_IG_baratto;

import java.util.HashMap;

import utility.InputDati;

public class Accesso {
	private static GruppoConf configuratori= new GruppoConf();
	private static GruppoFruitori fruitori = new GruppoFruitori(); 
	private static final String USERNAME_PROVVISORIA = "user";
	private static final String PASSWORD_PROVVISORIA = "A20M29O30";
												
	public static void accedi() {
		
		String nomeUser = InputDati.leggiStringaNonVuota("\ninserisca il suo nome utente: ");
		String pass = InputDati.leggiStringaNonVuota("inserisci la tua password: ");
	
		Configuratore conf = new Configuratore (nomeUser, pass);
		Fruitore fruitore = new Fruitore(nomeUser, pass);
		
		if(checkDefaultCred(conf)) {			//checkSignIn � true se le credenziali inserite sono quelle predefinite
			registrati(true);
			MenuConfiguratore.menuPrincipale();
			return;
		}
	
		boolean checkConf  = configuratori.check_conf(conf);	//true se esistono le credenziali 
		boolean checkFruitore = fruitori.check_fruitore(fruitore);	
		
		if(checkConf) {
			IOConfiguratore.msgBenvenuto(nomeUser);
			MenuConfiguratore.menuPrincipale();
		}
		else if(checkFruitore) {
			IOFruitore.msgBenvenuto(nomeUser);
			Fruitore updatedFruitore =  MenuFruitore.printMenu(fruitori.getFruitore(nomeUser));
			fruitori.setFruitore(updatedFruitore);
		}
		else
			IOGeneric.msgCredNotExist();
	}
	
	
	public static void registrati(boolean isConf) {
		if(isConf)
			IOGeneric.msgCredProvvis();
		IOGeneric.msgRegistrazione();

		String nomeUser;
		String pass ;
		boolean flag;
		boolean u_tooLong , p_tooLong;
		
		do {
			nomeUser = InputDati.leggiStringaNonVuota("\ninserisca il nome utente: ");
			u_tooLong= checkLength(nomeUser);
			
			pass =  InputDati.leggiStringa("inserisca la password: "); 
			p_tooLong= checkLength(pass);
			
			flag = isConf ? configuratori.check_username(nomeUser) :  fruitori.check_username(nomeUser);
			flag = flag ? true : configuratori.check_username(nomeUser) ;
			
			if(u_tooLong)
				IOGeneric.msgNameLong();
			if(p_tooLong)
				IOGeneric.msgPassLong();
			if(flag)
				IOGeneric.msgUserExist();
		}while(flag || u_tooLong || p_tooLong);
		
		
		IOGeneric.printBenvenuto();
		if(isConf) {
			Configuratore conf = new Configuratore (nomeUser, pass);
			configuratori.aggiungiConf(conf);
		}
		else{
			Fruitore fruitore = new Fruitore (nomeUser, pass);
			fruitori.aggiungiFruitore(fruitore);
			MenuFruitore.printMenu(fruitore);
		}
		
	}
	
	
	private static boolean checkLength(String l) {
		
		return l.length() >= 15;
	}
	
	private static boolean checkDefaultCred(Configuratore conf) {
		return (conf.getUsername().equals(USERNAME_PROVVISORIA)) && (conf.getPassword().equals(PASSWORD_PROVVISORIA)) ;
	}
	
	public static GruppoConf getConfiguratori() {
		return configuratori;
	}

	public static void setConfiguratori(GruppoConf configuratori) {
		Accesso.configuratori = configuratori;
	}
	
	public static GruppoFruitori getFruitori() {
		return fruitori;
	}
	
	public static void setFruitori(GruppoFruitori fruitori) {
		Accesso.fruitori = fruitori;
	}

	public static void setGruppoConf(HashMap<String, Configuratore> gruppo) {
		configuratori.setGruppo(gruppo);
	}
	public static void setGruppoFruitore(HashMap<String, Fruitore> gruppo) {
		fruitori.setGruppo(gruppo);
	}
	
	
}
