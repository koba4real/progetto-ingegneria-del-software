package data;

import java.io.File;

import barattoController.AccessController;
import barattoModel.Accesso;
import barattoModel.GestioneGerarchie;
import barattoModel.ListaOfferteAccoppiate;
import barattoModel.ParametriDiScambio;

public class DataFacade {
	
	private static File fileCredenzialiConf = new File("credenzialiConfiguratori.json");
	private static File fileDataFruitori = new File("dataFruitori.json");
	private static File fileGerarchie = new File("dataGerarchie.json");
	private static File fileListaOfferteAccoppiate = new File("listaOfferteAccoppiate.json");
	private static File fileParametriDiScambio = new File("dataParametri.json");
	private static File fileGerarchieInput = new File("input/dataGerarchie.json");
	private static File fileParametriDiScambioInput = new File("input/dataParametri.json");
	
	public static void saveData() {	
		DatiCredenzialiConfiguratore.save(fileCredenzialiConf);
		DatiFruitori.save(fileDataFruitori);
		DatiGerarchie.save(fileGerarchie);
		DatiListaOfferteAccoppiate.save(fileListaOfferteAccoppiate);
		DatiParametriDiScambio.save(fileParametriDiScambio);
		AccessController.salvataggioEffettuato();
	}
	
	public static void importData() {	
		Accesso.setGruppoConf(DatiCredenzialiConfiguratore.importaDaFile(fileCredenzialiConf));
		Accesso.setGruppoFruitore(DatiFruitori.importaDaFile(fileDataFruitori));
		GestioneGerarchie.setListaDiGerarchie(DatiGerarchie.importaDaFile(fileGerarchie));
		ListaOfferteAccoppiate.setListaOfferteAccoppiate(DatiListaOfferteAccoppiate.importaDaFile(fileListaOfferteAccoppiate));
		ParametriDiScambio.setParam(DatiParametriDiScambio.importaDaFile(fileParametriDiScambio));
	}
	
	public static void importFromInput() {

		if(DatiInput.importGerarchie(fileGerarchieInput)==null&&DatiInput.importParametri(fileParametriDiScambioInput)==null) {
			AccessController.erroreInput();
			return;
		}
		GestioneGerarchie.setListaDiGerarchie(DatiInput.importGerarchie(fileGerarchieInput));
		ParametriDiScambio.setParam(DatiInput.importParametri(fileParametriDiScambioInput));
		AccessController.inputLoad();
	}

}
