package barattoController;

import barattoModel.Accesso;
import barattoModel.Configuratore;
import barattoModel.Fruitore;
import barattoModel.Utente;
import barattoView.IOGeneric;


public class AccessController {
	
	public static void initialUSer() {
		String nome = IOGeneric.nomeUser();
		String pass = IOGeneric.passUser();
		Utente user = Accesso.getFruitori().checkUser(new Fruitore(nome,pass)) ? new Fruitore(nome,pass) : new Configuratore(nome, pass);
		Accesso.accedi(user);
	}
	
	public static void accessError() {
		IOGeneric.msgCredNotExist();
	}
	
	public static String registraNome(boolean isConf) {
		if(isConf)
			IOGeneric.msgCredProvvis();
		IOGeneric.msgRegistrazione();
		
		String nomeUser;
		boolean flag;
		boolean u_tooLong;
		
		do {
			nomeUser = IOGeneric.nomeUser();
			u_tooLong= checkLength(nomeUser);
		
			
			flag = isConf ? Accesso.getConfiguratori().check_username(nomeUser) : Accesso.getFruitori().check_username(nomeUser);
			flag = flag ? true : Accesso.getConfiguratori().check_username(nomeUser) ;
			
			if(u_tooLong)
				IOGeneric.msgNameLong();
			if(flag)
				IOGeneric.msgUserExist();
		}while(flag || u_tooLong);
		
		return nomeUser;	
	}
	
	public static String registraPass() {
		String pass ;
		boolean  p_tooLong;
		
		do {
			pass =  IOGeneric.passUser(); 
			p_tooLong= checkLength(pass);
				
			if(p_tooLong)
				IOGeneric.msgPassLong();

		}while(p_tooLong);
		
		IOGeneric.printBenvenuto();
		return pass;
	}
	
	private static boolean checkLength(String l) {
		
		return l.length() >= 15;
	}
	
	public static void salvataggioEffettuato() {
		IOGeneric.printSaved();
	}
	
	public static void erroreInput() {
		IOGeneric.msgErorInputDati();
	}
	public static void inputLoad() {
		IOGeneric.msgDatiInputCaricati();
	}
	
}
