package data;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.codehaus.jackson.map.ObjectMapper;

import barattoController.AccessController;
import barattoModel.Categoria;
import barattoModel.GestioneGerarchie;
import barattoModel.ParametriDiScambio;
import barattoView.IOGeneric;
import treeNodePackage.TreeNode;
import utility.ObjectSerializer;

public class DatiInput {
	private static ObjectMapper mapper = new ObjectMapper();

	
	public static ArrayList<TreeNode<Categoria>> importGerarchie(File file){	
			boolean fileNotFound = false;
			ArrayList<TreeNode<Categoria>> gerarchie = new ArrayList<>();
			
			try {
				String stringGerarchie = mapper.readValue(file, String.class);
				
				if( stringGerarchie!=null ) {
					gerarchie = (ArrayList<TreeNode<Categoria>>) ObjectSerializer.deserialize(stringGerarchie);	
					GestioneGerarchie.setListaDiGerarchie(gerarchie);					
				}				
			}catch(FileNotFoundException ex) {
				fileNotFound = true;
			}
			catch(IOException e) {
				e.printStackTrace();
			}
			if(fileNotFound)
				return null;
			return gerarchie;
		}
	public static ArrayList<Object> importParametri(File file){
			boolean fileNotFound = false;
			ArrayList<Object> parametri  = new ArrayList<>();
			
			try {
				String parametriString = mapper.readValue(file, String.class);	
				if(parametriString != null) {
					parametri = (ArrayList<Object>) ObjectSerializer.deserialize(parametriString);
					ParametriDiScambio.setParam(parametri);
				}	
			}catch(FileNotFoundException ex) {
				fileNotFound = true;
			}
			catch(IOException e) {
				e.printStackTrace();
			}

			if(fileNotFound)
				return null;
			return parametri;
	}
	
}
