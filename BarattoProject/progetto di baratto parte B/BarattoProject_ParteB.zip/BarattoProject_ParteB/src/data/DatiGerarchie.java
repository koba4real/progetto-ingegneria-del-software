package data;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import org.codehaus.jackson.map.ObjectMapper;

import barattoModel.Categoria;
import barattoModel.GestioneGerarchie;
import treeNodePackage.TreeNode;
import utility.ObjectSerializer;

public class DatiGerarchie {
	
	private static ObjectMapper mapper = new ObjectMapper();
	
	public static void save(File file) {
		String listaGerarchieString = ObjectSerializer.serialize(GestioneGerarchie.getListaDiGerarchie());
		try {
			mapper.writeValue(file, listaGerarchieString);
			}catch(IOException e) {
			e.printStackTrace();	
		}	
	}
	public static ArrayList<TreeNode<Categoria>> importaDaFile(File file){	//controlla in caso sia null
		
		ArrayList<TreeNode<Categoria>> gerarchie = new ArrayList<>();
		
		try{
			String stringGerarchie = mapper.readValue(file, String.class);
			
			if( stringGerarchie!=null ) {
				gerarchie = (ArrayList<TreeNode<Categoria>>) ObjectSerializer.deserialize(stringGerarchie);						
			}		
		}catch(FileNotFoundException ex){}
		catch(IOException e) {
			e.printStackTrace();
		}	
		return gerarchie;
	}

}
