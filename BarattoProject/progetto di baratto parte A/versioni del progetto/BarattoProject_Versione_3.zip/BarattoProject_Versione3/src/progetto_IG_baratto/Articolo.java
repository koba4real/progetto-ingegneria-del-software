package progetto_IG_baratto;

import java.io.Serializable;
import java.util.ArrayList;

public class Articolo implements Serializable{
	
	private Categoria categoria;
	private ArrayList<CampoNativo> campi;

	public Articolo(Categoria categoria) {
		this.categoria = categoria;
		campi = this.categoria.getCampi();
	}

	public ArrayList<CampoNativo> getCampi() {
		return campi;
	}

	public void setCampi(ArrayList<CampoNativo> campi) {
		this.campi = campi;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	@Override
	public String toString() {
		return "Articolo: " + categoria.getNome() + campi.toString();
	}
	
	
}
