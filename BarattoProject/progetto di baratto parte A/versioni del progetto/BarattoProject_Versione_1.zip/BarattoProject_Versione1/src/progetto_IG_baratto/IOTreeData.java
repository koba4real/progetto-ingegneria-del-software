package progetto_IG_baratto;

import java.util.ArrayList;

import utility.InputDati;

public class IOTreeData {
	
	private static ArrayList<String> nomiRootCat = new ArrayList<String>();
	
	public static Categoria readCategoriaRadice() {
		
		String 	nome = InputDati.leggiStringaNonVuota("Inserisci il nome della Categoria Radice: ");	
		
		while( checkRootName(nome) ){	
			System.out.println("Attenzione! il nome della categoria radice � gia esistente");
			nome = InputDati.leggiStringaNonVuota("Inserisci il nome della Categoria Radice: ");	
		};
		
		nomiRootCat.add(nome);
		
		String descrizione = InputDati.leggiStringaNonVuota("Inserisci la descrizione della categoria "+nome + ": ");
		CampoNativo campoStato = new CampoNativo("Stato di conservazione", true);
		CampoNativo campoDesc = new CampoNativo("Descrizione libera", false);
		Categoria rootCat = new Categoria(nome, descrizione);
		rootCat.addCampo(campoStato);
		rootCat.addCampo(campoDesc);
		
		rootCat.addCampi(readCampi(rootCat));//controllo che nomi dei campi aggiunti non sia uguale ai campi di default
		return rootCat;
	}

	public static Categoria readCategoria() {
		String nome = InputDati.leggiStringa("Inserisci il nome della Categoria: ");
		String descrizione = InputDati.leggiStringa("Inserisci Descrizione: ");
		Categoria categoria = new Categoria(nome, descrizione);
		return categoria;
	}
	
	public static Categoria setCampi(Categoria cat) {
		cat.addCampi(readCampi(cat));
		return cat;
	}
	
	public static void listaIsEmpty() {
		System.out.println("Attenzione non sono state create gerarchie!");
	}
	
	public static void noParent() {
		System.out.println("Attenzione la categoria radice non ha una categoria padre");
	}
	
	private static boolean checkRootName(String nome) {
		
		for(String nomeLista: nomiRootCat) {
			 if( nomeLista.equalsIgnoreCase(nome)) 
				 return true;
		}
		return false;	
	}
	
	private static ArrayList<CampoNativo> readCampi(Categoria cat) {
		
		ArrayList<CampoNativo> campiNativi = new ArrayList<CampoNativo>();
		
		while( InputDati.yesOrNo("vuoi inserire campi nativi? ") ) {		//attenzione se non aggiunge nulla hai array null
			
			String nome = InputDati.leggiStringaNonVuota("Inserisci il nome del campo nativo:");
			
			while( checkNomeCampi(nome, cat) ){
				System.out.println("ATTENZIONE! il nome del campo inserito � gi� esistente!");
				nome = InputDati.leggiStringaNonVuota("Inserisci il nome del campo nativo:");	
			}	
			
			boolean obbligatorio = InputDati.yesOrNo("questo campo nativo � obbligatori? ");
			campiNativi.add(new CampoNativo(nome, obbligatorio));
		}
		
		return campiNativi;
	}
	
	private static boolean checkNomeCampi(String nome, Categoria cat) {
		for(CampoNativo c : cat.getCampiNativi()) {
			if(c.getNome().equalsIgnoreCase(nome))
				return true;
		}
		
		return false;
	}

	public static void setNomiRoot (ArrayList<String> nomi) {
		nomiRootCat = nomi;
	}
	
}
