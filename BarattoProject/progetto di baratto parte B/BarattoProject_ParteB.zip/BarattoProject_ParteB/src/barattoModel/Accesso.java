package barattoModel;

import java.util.ArrayList;
import java.util.HashMap;

import barattoController.AccessController;
import barattoController.MenuConfiguratore;
import barattoController.MenuFruitore;


public class Accesso {
	private static GruppoConf configuratori= new GruppoConf();
	private static GruppoFruitori fruitori = new GruppoFruitori(); 
	private static final String USERNAME_PROVVISORIA = "user";
	private static final String PASSWORD_PROVVISORIA = "A20M29O30";
												
	public static void accedi(Utente utente) {
			
		if(checkDefaultCred(utente)) {			//checkSignIn � true se le credenziali inserite sono quelle predefinite
			registrati(true);
			MenuConfiguratore.menuPrincipale();
			return;
		}

		if(configuratori.checkUser(utente)) {
			MenuConfiguratore.menuPrincipale();
		}
		else if(fruitori.checkUser(utente)) {
			Fruitore updatedFruitore =  MenuFruitore.printMenu(fruitori.getFruitore(utente.getUsername()));
			fruitori.setFruitore(updatedFruitore);
		}
		else
			AccessController.accessError();
	}

	public static void registrati(boolean isConf) {

		String nomeUser = AccessController.registraNome(isConf);
		String pass = AccessController.registraPass();
		
		if(isConf) {
			Configuratore conf = new Configuratore (nomeUser.toLowerCase(), pass);
			configuratori.aggiungiConf(conf);
		}
		else{
			Fruitore fruitore = new Fruitore (nomeUser.toLowerCase(), pass);
			fruitori.aggiungiFruitore(fruitore);
			MenuFruitore.printMenu(fruitore);
		}	
	}
	
	public static ArrayList<Offerta> offerteAperte(Categoria cat){
		ArrayList<Offerta> offerteAperte = new ArrayList<>();
		fruitori.getGruppo().forEach( (k,v) -> {
			Fruitore f = (Fruitore) v;
			for(Offerta off : f.getOfferte()) {
				if( off.getArticolo().getCategoria().getNome().equalsIgnoreCase(cat.getNome()) && off.getStatoOfferta().equals(StatoOfferta.APERTA))
					offerteAperte.add(off);		
			}
		});
		return offerteAperte;
	}
	
	public static ArrayList<Offerta> offerteDaScambiare(Offerta offerta){
		ArrayList<Offerta> offerteAperte = new ArrayList<>();
		Categoria categ = offerta.getArticolo().getCategoria();
		Accesso.getFruitori().getGruppo().forEach( (k,v) -> {
			Fruitore f = (Fruitore) v;
			for(Offerta off : f.getOfferte()) {
				if( off.getArticolo().getCategoria().getNome().equalsIgnoreCase(categ.getNome()) && off.isOffertaAperta() && !f.getUsername().equalsIgnoreCase((offerta.getAutoreOfferta())) )
					offerteAperte.add(off);		
			}
		});
		
		return offerteAperte;
		
	}
	
	public static ArrayList<Offerta> offerteInScambioEChiuse(Categoria categoria){
		ArrayList<Offerta> offerteInScambio = new ArrayList<Offerta>();
		
		fruitori.getGruppo().forEach( (k,v) -> {
			Fruitore f = (Fruitore) v;
			for(Offerta off : f.getOfferte()) {
				boolean check = off.getStatoOfferta().equals(StatoOfferta.IN_SCAMBIO) || off.getStatoOfferta().equals(StatoOfferta.CHIUSA);
				if( off.getArticolo().getCategoria().getNome().equalsIgnoreCase(categoria.getNome()) && ( check ))
					offerteInScambio.add(off);		
			}
		});
		return offerteInScambio;
	}
	
	private static boolean checkDefaultCred(Utente user) {
		return (user.getUsername().equals(USERNAME_PROVVISORIA)) && (user.getPassword().equals(PASSWORD_PROVVISORIA)) ;
	}
	
	public static GruppoConf getConfiguratori() {
		return configuratori;
	}

	public static void setConfiguratori(GruppoConf configuratori) {
		Accesso.configuratori = configuratori;
	}
	
	public static GruppoFruitori getFruitori() {
		return fruitori;
	}
	
	public static void setFruitori(GruppoFruitori fruitori) {
		Accesso.fruitori = fruitori;
	}

	public static void setGruppoConf(HashMap<String, Configuratore> gruppo) {
		configuratori.setGruppo(gruppo);
	}
	public static void setGruppoFruitore(HashMap<String, Fruitore> gruppo) {
		fruitori.setGruppo(gruppo);
	}
	
	
}
