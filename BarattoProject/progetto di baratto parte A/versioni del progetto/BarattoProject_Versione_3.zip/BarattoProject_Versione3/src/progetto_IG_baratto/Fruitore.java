package progetto_IG_baratto;

import java.io.Serializable;
import java.util.ArrayList;

public class Fruitore implements Serializable{
	private String username ;
	private String password;
	private ArrayList<Articolo> articoli = new ArrayList<Articolo>();
	private ArrayList<Offerta> offerte = new ArrayList<Offerta>();
	
	public Fruitore() {
		
	}
	
	public Fruitore(String username, String password) {
		this.username = username;
		this.password = password;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void addOfferta(Offerta offerta) {
		this.offerte.add(offerta);
	}

	public ArrayList<Offerta> getOfferte() {
		return offerte;
	}
	public ArrayList<Articolo> getArticoli() {
		return articoli;
	}
	public void setArticoli(ArrayList<Articolo> articoli) {
		this.articoli = articoli;
	}
	public void addArticolo(Articolo articolo) {
		this.articoli.add(articolo);
	}
	public void removeArticolo(Articolo articolo) {
		int index = articoli.indexOf(articolo);
		this.articoli.remove(index);
	}
	public void ritiraOfferta(Offerta offerta) {
		int index = this.offerte.indexOf(offerta);
		this.offerte.get(index).ritiraOfferta();
	}
	
	


}
