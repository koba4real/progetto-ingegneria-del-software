package progetto_IG_baratto;

import java.util.ArrayList;

import TreeNodeProject.TreeNode;
import utility.InputDati;

public class IOFruitore {
	
	public static void visParametriDiScambio() {
		if(ParametriDiScambio.getPiazza() == null) {
			System.out.println("Non sono stati inseriti Parametri di scambio");
			return;
		}
		System.out.println("\nParametri di scambio: ");
		System.out.println("Piazza: " + ParametriDiScambio.getPiazza()+";");
		System.out.print("Luogo: ");
		for(String luogo: ParametriDiScambio.getLuoghi())
			System.out.print(" " + luogo + ";");
		System.out.println();
		System.out.print("Giorni: ");
		for(GiorniDellaSettimana giorno: ParametriDiScambio.getGiorni())
			System.out.print(" " + giorno.getGiorno() + ";");
		System.out.println();
		System.out.print("Intervalli Orari: ");
		for(IntervalloOrario intervallo: ParametriDiScambio.getIntervalliOrari()) {
			String text = intervallo.toString().replace(',', ':');
			System.out.print(" " + text + ";  ");
		}
		System.out.println();
	}
	
	public static void visRoots() {
		if(GestioneGerarchie.getListaDiGerarchie() == null || GestioneGerarchie.getListaDiGerarchie().isEmpty()) {
			System.out.println("Non sono ancora state create gerarchie");
			return;
		}
		System.out.println("\nCategorie radice delle gerarchie: ");
		for(TreeNode<Categoria> albero : GestioneGerarchie.getListaDiGerarchie()) {
			System.out.println("Nome: " + albero.data.getNome() + ",  Descrizione: "+albero.data.getDescrizione()+";");
		}
	}
	
	
	public static Articolo sceltaArticolo(Fruitore fruitore) {
		if( fruitore.getArticoli() == null ||fruitore.getArticoli().isEmpty()) {
			System.out.println("Non ci sono articoli da poter pubblicare!");
			return null;
		}
		System.out.println("\nScegli l'articolo da pubblicare: ");
		ArrayList<Articolo> articoli = fruitore.getArticoli();
		for(int i=0; i< articoli.size(); i++) {
			System.out.println(i+1 +") " + articoli.get(i));
		}
		
		int scelta = InputDati.leggiIntero("Digita un numero: ", 1 , articoli.size());
		
		return articoli.get(scelta-1);
	}
	public static Offerta sceltaOffertaAperta(Fruitore fruitore) {
		ArrayList<Offerta> offerte = fruitore.getOfferte();
		boolean existOfferta = false;
		ArrayList<Integer> numList = new ArrayList<>();
		for(Offerta offerta : offerte) {
			if(offerta.isOffertaAperta())
				existOfferta = true;
		}	
		if( offerte == null ||offerte.isEmpty() || !existOfferta) {
			System.out.println("Non ci sono offerte da poter ritirare!");
			return null;
		}
		System.out.println("\nScegli l'offerta da ritirare: ");
		for(int i=0; i< offerte.size(); i++) {
			if(offerte.get(i).isOffertaAperta()) {
				System.out.println(i+1 +") " + offerte.get(i));
				numList.add(i+1);
			}
		}
		int scelta = InputDati.leggiIntero("Digita un numero: ", 1 , offerte.size());
		while( ! numList.contains(scelta) ){
			System.out.println("Attenzione: � richiesto uno dei numeri sopra elencati");
			scelta = InputDati.leggiIntero("Digita un numero: ", 1 , offerte.size());
		};
		return offerte.get(scelta-1);
	}
	
	public static Offerta sceltaOffertaRitirata(Fruitore fruitore) {
		ArrayList<Offerta> offerte = fruitore.getOfferte();
		boolean existOfferta = false;
		ArrayList<Integer> numList = new ArrayList<>();
		for(Offerta offerta : offerte) {
			if( ! offerta.isOffertaAperta())
				existOfferta = true;
		}	
		if( offerte == null ||offerte.isEmpty() || !existOfferta) {
			System.out.println("Non ci sono offerte da poter riaprire!");
			return null;
		}
		System.out.println("\nScegli l'offerta da riaprire: ");
		for(int i=0; i< offerte.size(); i++) {
			if( ! offerte.get(i).isOffertaAperta() ) {
				System.out.println(i+1 +") " + offerte.get(i));
				numList.add(i+1);
			}
		}
		int scelta = InputDati.leggiIntero("Digita un numero: ", 1 , offerte.size());
		while( ! numList.contains(scelta)){
			System.out.println("Attenzione: � richiesto uno dei numeri sopra elencati");
			scelta = InputDati.leggiIntero("Digita un numero: ", 1 , offerte.size());
		};
		return offerte.get(scelta-1);
	}
	public static Articolo inizializzArt(Categoria cat) {
		Articolo articolo = new Articolo(cat);
		ArrayList<CampoNativo> campi = articolo.getCampi();
		
		System.out.println("Compila i campi relativi all'articolo: ");
		for(CampoNativo campo: campi) {
			if(campo.isOblligatorio())
				campo.setCompilazioneCampo(InputDati.leggiStringaNonVuota(campo.getNome() + "(OBBLIGATORIO): "));
			else
				campo.setCompilazioneCampo(InputDati.leggiStringa(campo.getNome()+": "));
		}
		articolo.setCampi(campi);
		return articolo;
	}
	public static void visOfferte(ArrayList<Offerta> offerte) {
		if(offerte == null || offerte.isEmpty()) {
			System.out.println("Non sei autore di alcun Offerta!");
			return;
		}
		for(Offerta off: offerte) {
			System.out.println(off.toString());
		}
	}
	
	public static void msgArticolo() {
		System.out.println("ATTENZIONE non � possibile creare un articolo in qunato non sono state create gerarchie");
	}
	
	public static void msgBenvenuto(String nome) {
		System.out.println("Benvenuto "+nome+"!");
		
	}
	
	public static void msgPubblicazione() {
		System.out.println("Articolo pubblicato con successo!");
	}
	public static void msgRitiroOfferta() {
		System.out.println("Offerta ritirata!");
	}
	public static void msgRiapriOfferta() {
		System.out.println("Offerta riaperta!");
	}
}
