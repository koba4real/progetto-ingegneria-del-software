package testingPackage;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import barattoController.MenuFruitore;
import barattoController.MenuGestioneOfferte;
import barattoModel.Accesso;
import barattoModel.Articolo;
import barattoModel.Categoria;
import barattoModel.Configuratore;
import barattoModel.Fruitore;
import barattoModel.GiorniDellaSettimana;
import barattoModel.GruppoConf;
import barattoModel.GruppoFruitori;
import barattoModel.IntervalloOrario;
import barattoModel.ListaOfferteAccoppiate;
import barattoModel.Offerta;
import barattoModel.OfferteAccoppiate;
import barattoModel.ParametriDiScambio;
import barattoModel.StatoOfferta;
import junit.framework.Assert;

class Testing_Requisito_e_Metodo {

	@Test
	void testFissareIValoriDeiPramDiScambio() {
		ArrayList<String> luoghi = new ArrayList<String>();
		ArrayList<IntervalloOrario> intervalli = new ArrayList<IntervalloOrario>();
		ParametriDiScambio.setPiazza("vittoria");
		luoghi.add("brescia");
		ParametriDiScambio.setLuoghi(luoghi);
		ParametriDiScambio.addGionrno(GiorniDellaSettimana.DOMENICA);
		IntervalloOrario intervallo = new IntervalloOrario(12.30, 13.30);
		intervalli.add(intervallo);
		ParametriDiScambio.setIntervalliOrari(intervalli);
		ParametriDiScambio.setScadenza(1);
		
		Assert.assertEquals("vittoria", ParametriDiScambio.getPiazza());
		Assert.assertEquals("brescia", ParametriDiScambio.getLuoghi().get(0));
		Assert.assertEquals(GiorniDellaSettimana.DOMENICA, ParametriDiScambio.getGiorni().get(0));
		Assert.assertEquals(12.30, ParametriDiScambio.getIntervalliOrari().get(0).getOrarioInizio());
		Assert.assertEquals(13.30, ParametriDiScambio.getIntervalliOrari().get(0).getOrarioFine());
		Assert.assertEquals(1, ParametriDiScambio.getScadenza());
		
	}
	
	@Test
	void testOffertaAperta() {
		Fruitore f = new Fruitore("okba", "01");
		Offerta of = new Offerta(new Articolo(new Categoria("moto", "mezzo")), f.getUsername());
		f.addOfferta(of);
		Assert.assertEquals(StatoOfferta.APERTA, f.getOfferte().get(0).getStatoOfferta());
		Assert.assertEquals("okba", f.getOfferte().get(0).getAutoreOfferta());
	}
	
	@Test
	void testCheckConfiguratoreExist() {
		GruppoConf g = new GruppoConf();
		GruppoFruitori f = new GruppoFruitori();
		g.aggiungiConf(new Configuratore("okba", "abc1"));
		f.aggiungiFruitore(new Fruitore("musab","ab99"));
		Assert.assertTrue( g.checkUser(new Configuratore("okba", "abc1")));
		Assert.assertTrue(f.checkUser(new Fruitore("musab", "ab99")));
	}
	
	@Test
	void testCheckConfiguratoreNotExist() {
		GruppoConf g = new GruppoConf();
		GruppoFruitori f = new GruppoFruitori();
		g.aggiungiConf(new Configuratore("okba", "abc1"));
		f.aggiungiFruitore(new Fruitore("musab","ab99"));
		Assert.assertFalse( g.checkUser(new Configuratore("okba", "ABC1")));
		Assert.assertFalse(f.checkUser(new Fruitore("musab", "AB99")));
	}
	
	
	@Test
	void testListaProposte() {
		Fruitore f = new Fruitore("okba","01");
		Offerta offA = new Offerta(new Articolo(new Categoria("moto", "mezzo")), f.getUsername());
		offA.setStatoOfferta(StatoOfferta.ACCOPPIATA);
		Offerta offS = new Offerta(new Articolo(new Categoria("moto", "mezzo")), f.getUsername());
		offS.setStatoOfferta(StatoOfferta.SELEZIONATA);
		ListaOfferteAccoppiate.addOfferteAccoppiate(new OfferteAccoppiate(offA, offS));
		OfferteAccoppiate offAcc = ListaOfferteAccoppiate.getListaOfferteAccoppiate().get(0);
		f.addOfferta(offS);
		ArrayList<OfferteAccoppiate> lista = f.getListaProposte();
		Assert.assertEquals(lista.get(0), offAcc);
	
			
	}
	
	
	

}
