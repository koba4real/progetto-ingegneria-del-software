package progetto_IG_baratto;
import TreeNodeProject.TreeNode;

public class GestioneAlbero {
	
	public static TreeNode<Categoria> inserisciSottocategoria(TreeNode<Categoria> nodo) {
		Categoria cat = IOConfiguratore.readCategoria();
		while( checkNameCat(cat.getNome(), nodo) ){
			System.out.println("Attenzione! il nome della sottocategoria inserito � gi� presente all'interno della gerarchia");
			cat = IOConfiguratore.readCategoria();
		}
		
			//gestire ereditariet� e inserimento dei nuovi campi nativi 
		TreeNode<Categoria> nodoFiglio = nodo.addChild(cat) ;
		nodoFiglio.data.addCampi(nodo.data.getCampi());
		nodoFiglio.data.setCampi(IOConfiguratore.setCampi(cat).getCampi());
		
		return nodoFiglio;	
	}
	
	
	public static void visAlbero(TreeNode<Categoria> nodo) {
		for (TreeNode<Categoria> node : nodo.getTreeRoot()) {
			String indent = createIndent(node.getLevel());
			System.out.println(indent + node.data + "\t" + node.data.getCampi());
		}
	}
	

	private static boolean checkNameCat(String nome, TreeNode<Categoria> nodo) {
		TreeNode<Categoria> rootNode = nodo.getTreeRoot();
		for (TreeNode<Categoria> node : rootNode ) {
			if( node.data.getNome().equalsIgnoreCase(nome) )
				return true;
		}
		return false;
	}
	
	
	private static String createIndent(int depth) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < depth; i++) {
			sb.append(' ');
		}
		return sb.toString();
	}
	
}
