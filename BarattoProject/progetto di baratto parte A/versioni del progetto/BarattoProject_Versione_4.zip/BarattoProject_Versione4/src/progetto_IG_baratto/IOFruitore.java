package progetto_IG_baratto;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;

import TreeNodeProject.TreeNode;
import utility.InputDati;

public class IOFruitore {
	
	public static void visParametriDiScambio() {
		if(ParametriDiScambio.getPiazza() == null) {
			System.out.println("Non sono stati inseriti Parametri di scambio");
			return;
		}
		System.out.println("\nParametri di scambio: ");
		System.out.println("Piazza: " + ParametriDiScambio.getPiazza()+";");
		System.out.print("Luogo: ");
		for(String luogo: ParametriDiScambio.getLuoghi())
			System.out.print(" " + luogo + ";");
		System.out.println();
		System.out.print("Giorni: ");
		for(GiorniDellaSettimana giorno: ParametriDiScambio.getGiorni())
			System.out.print(" " + giorno.getGiorno() + ";");
		System.out.println();
		System.out.print("Intervalli Orari: ");
		for(IntervalloOrario intervallo: ParametriDiScambio.getIntervalliOrari()) {
			String text = intervallo.toString().replace(',', ':');
			System.out.print(" " + text + ";  ");
		}
		System.out.println();
	}
	
	public static void visRoots() {
		if(GestioneGerarchie.getListaDiGerarchie() == null || GestioneGerarchie.getListaDiGerarchie().isEmpty()) {
			System.out.println("Non sono ancora state create gerarchie");
			return;
		}
		System.out.println("\nCategorie radice delle gerarchie: ");
		for(TreeNode<Categoria> albero : GestioneGerarchie.getListaDiGerarchie()) {
			System.out.println("Nome: " + albero.data.getNome() + ",  Descrizione: "+albero.data.getDescrizione()+";");
		}
	}
	
	
	public static Offerta sceltaArticolo(Fruitore fruitore) {
		if( fruitore.getOfferteNonPubliche() == null ||fruitore.getOfferteNonPubliche().isEmpty()) {
			System.out.println("Non ci sono articoli da poter pubblicare!");
			return null;
		}
		System.out.println("\nScegli l'articolo da pubblicare: ");
		ArrayList<Offerta> offerteNonPubblicate = fruitore.getOfferteNonPubliche();
		for(int i=0; i< offerteNonPubblicate.size(); i++) {
			System.out.println(i+1 +") " + offerteNonPubblicate.get(i).getArticolo());
		}
		
		int scelta = InputDati.leggiIntero("Digita un numero: ", 1 , offerteNonPubblicate.size());
		
		return offerteNonPubblicate.get(scelta-1);
	}
	public static Offerta sceltaOffertaAperta(Fruitore fruitore) {
		ArrayList<Offerta> offerte = fruitore.getOfferte();
		boolean existOfferta = false;
		ArrayList<Integer> numList = new ArrayList<>();
		for(Offerta offerta : offerte) {
			if(offerta.isOffertaAperta())
				existOfferta = true;
		}	
		if( offerte == null ||offerte.isEmpty() || !existOfferta) {
			System.out.println("Non ci sono offerte aperte da poter ritirare!");
			return null;
		}
		System.out.println("\nScegli l'offerta da ritirare: ");
		for(int i=0; i< offerte.size(); i++) {
			if(offerte.get(i).isOffertaAperta()) {
				System.out.println(i+1 +") " + offerte.get(i));
				numList.add(i+1);
			}
		}
		int scelta = InputDati.leggiIntero("Digita un numero: ", 1 , offerte.size());
		while( ! numList.contains(scelta) ){
			System.out.println("Attenzione: � richiesto uno dei numeri sopra elencati");
			scelta = InputDati.leggiIntero("Digita un numero: ", 1 , offerte.size());
		};
		return offerte.get(scelta-1);
	}
	
	public static Offerta sceltaOffertaRitirata(Fruitore fruitore) {
		ArrayList<Offerta> offerte = fruitore.getOfferte();
		boolean existOfferta = false;
		ArrayList<Integer> numList = new ArrayList<>();
		for(Offerta offerta : offerte) {
			if( offerta.getStatoOfferta().equals(StatoOfferta.RITIRATA))
				existOfferta = true;
		}	
		if( offerte == null ||offerte.isEmpty() || !existOfferta) {
			System.out.println("Non ci sono offerte ritirate da poter riaprire!");
			return null;
		}
		System.out.println("\nScegli l'offerta da riaprire: ");
		for(int i=0; i< offerte.size(); i++) {
			if( offerte.get(i).getStatoOfferta().equals(StatoOfferta.RITIRATA) ) {
				System.out.println(i+1 +") " + offerte.get(i));
				numList.add(i+1);
			}
		}
		int scelta = InputDati.leggiIntero("Digita un numero: ", 1 , offerte.size());
		while( ! numList.contains(scelta)){
			System.out.println("Attenzione: � richiesto uno dei numeri sopra elencati");
			scelta = InputDati.leggiIntero("Digita un numero: ", 1 , offerte.size());
		};
		return offerte.get(scelta-1);
	}
	public static ArrayList<CampoNativo> inizializzArt(Categoria cat) {
		ArrayList<CampoNativo> campi = cat.getCampi();
		
		System.out.println("Compila i campi relativi all'articolo: ");
		for(CampoNativo campo: campi) {
			if(campo.isOblligatorio())
				campo.setCompilazioneCampo(InputDati.leggiStringaNonVuota(campo.getNome() + "(OBBLIGATORIO): "));
			else
				campo.setCompilazioneCampo(InputDati.leggiStringa(campo.getNome()+": "));
		}
		return campi;
	}
	
	
	public static OfferteAccoppiate sceltaOffertaAppuntamento(Fruitore fruitore) {
		ArrayList<Offerta> offerte = fruitore.getOfferte();
		boolean existOfferta = false;
		ArrayList<Integer> numList = new ArrayList<>();
		for(Offerta offerta : offerte) {
			if(offerta.getStatoOfferta().equals(StatoOfferta.IN_SCAMBIO) && ! ListaOfferteAccoppiate.getOfferteById(offerta.getCoodiceID()).getlastFruitore().equals(fruitore.getUsername()))
				existOfferta = true;
		}
		
		if( offerte == null ||offerte.isEmpty() ||  !existOfferta ) {
			System.out.println("Non ci sono appuntamenti!");
			return null;
		}
		System.out.println("\nScegli quale appuntamento accettare o scartare: ");
		for(int i=0; i< offerte.size(); i++) {
			if(offerte.get(i).getStatoOfferta().equals(StatoOfferta.IN_SCAMBIO)) {
				System.out.println(i+1 +") " + offerte.get(i) + ListaOfferteAccoppiate.getOfferteById(offerte.get(i).getCoodiceID()).toString() );
				numList.add(i+1);
			}
		}
		System.out.println("0) esci");
		
		int scelta = InputDati.leggiIntero("Digita un numero: ", 0 , offerte.size());
		while( ! numList.contains(scelta) && scelta != 0 ){
			System.out.println("Attenzione: � richiesto uno dei numeri sopra elencati");
			scelta = InputDati.leggiIntero("Digita un numero: ", 0 , offerte.size());
		};
		
		if(scelta==0)
			return null;
		
		return ListaOfferteAccoppiate.getOfferteById(offerte.get(scelta-1).getCoodiceID());
	}
	

	public static Offerta sceltaOffertaDaProporre(Fruitore fruitore) {
		ArrayList<Offerta> offerte = fruitore.getOfferte();
		boolean existOfferta = false;
		ArrayList<Integer> numList = new ArrayList<>();
		for(Offerta offerta : offerte) {
			if(offerta.isOffertaAperta())
				existOfferta = true;
		}
		
		if( offerte == null ||offerte.isEmpty() ||  !existOfferta ) {
			System.out.println("Non ci sono offerte da poter proporre!");
			return null;
		}
		System.out.println("\nScegli l'offerta da proporre: ");
		for(int i=0; i< offerte.size(); i++) {
			if(offerte.get(i).isOffertaAperta()) {
				System.out.println(i+1 +") " + offerte.get(i));
				numList.add(i+1);
			}
		}
		int scelta = InputDati.leggiIntero("Digita un numero: ", 1 , offerte.size());
		while( ! numList.contains(scelta) ){
			System.out.println("Attenzione: � richiesto uno dei numeri sopra elencati");
			scelta = InputDati.leggiIntero("Digita un numero: ", 1 , offerte.size());
		};
		return offerte.get(scelta-1);
	}
	
	public static Offerta sceltaOffertaDaScambiare(Offerta offerta) {
		ArrayList<Offerta> offerteAperte = new ArrayList<>();
		ArrayList<Integer> numList = new ArrayList<>();
		Categoria categ = offerta.getArticolo().getCategoria();
		Accesso.getFruitori().getGruppo().forEach( (k,v) -> {
			Fruitore f = (Fruitore) v;
			for(Offerta off : f.getOfferte()) {
				if( off.getArticolo().getCategoria().getNome().equalsIgnoreCase(categ.getNome()) && off.isOffertaAperta() && !f.getUsername().equalsIgnoreCase((offerta.getAutoreOfferta())) )
					offerteAperte.add(off);		
			}
		});
		
		if( offerteAperte == null ||offerteAperte.isEmpty()) {
			System.out.println("Non ci sono offerte con le quali poter scambiare!");
			return null;
		}
		System.out.println("\nScegli l'offerta con la quale scambiare: ");
		for(int i=0; i< offerteAperte.size(); i++) {
			if(offerteAperte.get(i).isOffertaAperta()) {
				System.out.println(i+1 +") " + offerteAperte.get(i));
				numList.add(i+1);
			}
		}
		int scelta = InputDati.leggiIntero("Digita un numero: ", 1 , offerteAperte.size());
		while( ! numList.contains(scelta) ){
			System.out.println("Attenzione: � richiesto uno dei numeri sopra elencati");
			scelta = InputDati.leggiIntero("Digita un numero: ", 1 , offerteAperte.size());
		};
		return offerteAperte.get(scelta-1);
	}
	
	public static OfferteAccoppiate sceltaOffertaProposta(ArrayList<OfferteAccoppiate> offerte) {

		if( offerte == null ||offerte.isEmpty()) {
			System.out.println("Non ci sono proposte di baratto!");
			return null;
		}
		System.out.println("\nProposte di baratto: ");
		for(int i=0; i< offerte.size(); i++) {
				System.out.println(i+1 +") " + offerte.get(i).getOffertaAccoppiata());
		}
		System.out.println("0) esci");
		int scelta = InputDati.leggiIntero("Digita il numero della proposta da accettare: ", 0 , offerte.size());
		if(scelta==0)
			return null;
		return offerte.get(scelta-1);
		
	}
	public static OfferteAccoppiate leggiDatiScambio(OfferteAccoppiate offerte) {
		System.out.println("Inserire i dati per fissare l' Appuntamento: ");
		System.out.println("Scrivi il luogo in cui vorresti effettuare lo scambio");
		System.out.println("luoghi possibili: " + ParametriDiScambio.getLuoghi());
		String luogoScambio = InputDati.leggiStringaNonVuota("Luogo: ");
		while( ! ParametriDiScambio.getLuoghi().contains(luogoScambio)) {
			System.out.println("Attenzione bisogna inserie uno dei luoghi indicati");
			System.out.println("luoghi possibili: " + ParametriDiScambio.getLuoghi());
			luogoScambio = InputDati.leggiStringaNonVuota("Luogo: ");
		}
	
		String data = InputDati.leggiStringaNonVuota("Inserisci la data in cui vorresti effettuare lo scambio (esempio 2023-03-24) : ");
		boolean parseError = false; 
		LocalDate dataDiScambio = null;
		try {
			dataDiScambio = LocalDate.parse(data, DateTimeFormatter.ISO_DATE);
		}catch(DateTimeParseException dtpe) {
			parseError = true;
		}
		while(parseError) {
			parseError=false;
			data = InputDati.leggiStringaNonVuota("Attenzione la data inserita � nel formato scorretto, utilizzi il formato in esempio (2023-03-24)"
														+ "\nData di scambio: ");
			try {
				dataDiScambio = LocalDate.parse(data, DateTimeFormatter.ISO_DATE);
			}catch(DateTimeParseException dtpe) {
				parseError = true;
			}
		}
		
		System.out.println("Inserisci l'orario in cui vorresti effettuare lo scambio: ");
		System.out.println("Intervalli Orari possibili: " + ParametriDiScambio.getIntervalliOrari());
		double orarioScambio = InputDati.leggiDouble("Orario: ");
		while( ! IntervalloOrario.checkOrario(orarioScambio)) {
			System.out.println("Attenzione l'orario inserito � errato, riprovi");
			orarioScambio = InputDati.leggiDouble("Inserisci l'orario in cui vorresti effettuare lo scambio: ");
		}
		
		while( ! checkOrario(orarioScambio)) {
			System.out.println("Attenzione bisogna inserie un orario che sta tra gli intervali indicati e"
					+ "\ni soli orari possibili sono quelli dello scoccare dell'ora o della mezzora");
			System.out.println("orari possibili: " + ParametriDiScambio.getIntervalliOrari());
			orarioScambio = InputDati.leggiDouble("Orario: ");
		}
		
		System.out.println("Appuntamento Proposto!");
		offerte.setLuogoScabio(luogoScambio);
		offerte.setDataScambio(dataDiScambio);
		offerte.setOrarioScambio(orarioScambio);
		return offerte;
	}
	private static boolean checkOrario(double orario) {
		for(IntervalloOrario intervallo : ParametriDiScambio.getIntervalliOrari()) {
			if(orario >= intervallo.getOrarioInizio() && orario <= intervallo.getOrarioFine()) {
				int integer = (int)orario;
				double dec = orario - integer;
			    String value =  String.format("% .2f", dec) ;
			    boolean check =  value.equals(" 0,00")|| value.equals(" 0,30");
				return check;
			}
				
		}
		return false;
	}
	public static void visOfferte(ArrayList<Offerta> offerte) {
		if(offerte == null || offerte.isEmpty()) {
			System.out.println("Non sei autore di alcun Offerta!");
			return;
		}
		for(Offerta off: offerte) {
			System.out.println(off.toString());
		}
	}
	public static void visRisposte(Fruitore fruitore) {
		ArrayList<Offerta> offerte = fruitore.getOfferte();
		boolean existOfferta = false;
		for(Offerta offerta : offerte) {
			if( offerta.getStatoOfferta().equals(StatoOfferta.IN_SCAMBIO))
				existOfferta = true;
		}
		if(offerte == null || offerte.isEmpty() || !existOfferta ) {
			System.out.println("Non ci sono offerte in scambio!");
			return;
		}
		for(Offerta off: offerte) {
			if(off.getStatoOfferta().equals(StatoOfferta.IN_SCAMBIO)) {
				System.out.println(off.toString());
				if( ListaOfferteAccoppiate.getOfferteById(off.getCoodiceID()).getlastFruitore().equals(fruitore.getUsername()))
						System.out.print("\t\tIn attesa di una risposta, ");
				else
					System.out.print("\t\t");
				System.out.print("ultimo appuntamento fissato: ");
				System.out.print(ListaOfferteAccoppiate.getOfferteById(off.getCoodiceID()).toString() );
			}
		}
	}
	public static void msgArticolo() {
		System.out.println("ATTENZIONE non � possibile creare un articolo in qunato non sono state create gerarchie");
	}
	public static void msgOffChiusa() {
		System.out.println("Offerta chiusa!");
	}
	public static void msgBenvenuto(String nome) {
		System.out.println("Benvenuto "+nome+"!");	
	}
	public static void msgAltroAppuntamento() {
		System.out.println("Proponi un altro appuntamento: ");
	}
	public static void msgPubblicazione() {
		System.out.println("Articolo pubblicato con successo!");
	}
	public static void msgRitiroOfferta() {
		System.out.println("Offerta ritirata con successo!");
	}
	public static void msgRiapriOfferta() {
		System.out.println("Offerta riaperta con successo!");
	}
	public static void msgParamNonFix() {
		System.out.println("Attenzione non � possibile effettuare lo scambio in quanto non sono ancora stati settati i parametri di scambio!");
	}
	public static void msgNoProposte() {
		System.out.println("Non ci sono proposte di baratto!");
	}
}
