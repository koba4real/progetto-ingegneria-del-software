package progetto_IG_baratto;

import java.util.HashMap;

public class GruppoFruitori {
	private HashMap gruppo = new HashMap<String , Fruitore>() ; 


	
	public HashMap getGruppo() {
		return gruppo;
	}

	public void setGruppo(HashMap gruppo) {
		this.gruppo = gruppo;
	}
	
	public void aggiungiFruitore(Fruitore fruitore) {
		String s = fruitore.getUsername();
		gruppo.put(s, fruitore);
	}
	
	public void setFruitore(Fruitore fruitore) {
		this.gruppo.put(fruitore.getUsername(), fruitore);
	}
	
	public Fruitore getFruitore(String nome) {
		return (Fruitore) this.gruppo.get(nome);
	}
	
	public boolean check_username(String user) {	
		return gruppo.containsKey(user); // true se esiste gia il username nella hashmap
	}
	
	public boolean check_fruitore(Fruitore fruitore) {	 //true se esiste gi� il Fruitore
		if( ! check_username(fruitore.getUsername()))
			return false;
		String u = fruitore.getUsername();
		String p = fruitore.getPassword();
		Fruitore c = (Fruitore)gruppo.get(u);
		return  c.getPassword().equals(p);
	}

}
