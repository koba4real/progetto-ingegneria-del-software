package progetto_IG_baratto;

import java.io.Serializable;

public class CampoNativo implements Serializable{
	
	private String nome;
	private String compilazioneCampo;
	private boolean oblligatorio;
	
	public CampoNativo(String nome, boolean oblligatorio) {
		this.nome = nome;
		this.oblligatorio = oblligatorio;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCompilazioneCampo() {
		return compilazioneCampo;
	}
	public void setCompilazioneCampo(String compilazioneCampo) {
		this.compilazioneCampo = compilazioneCampo;
	}
	public boolean isOblligatorio() {
		return oblligatorio;
	}
	public void setOblligatorio(boolean oblligatorio) {
		this.oblligatorio = oblligatorio;
	}
	
	public String toString() {
		return nome + ": " + this.compilazioneCampo;
	}
	
	
}
