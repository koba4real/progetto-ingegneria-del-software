package progetto_IG_baratto;

import java.util.ArrayList;

import TreeNodeProject.TreeNode;
import utility.InputDati;

public class IOFruitore {
	
	public static void visParametriDiScambio() {
		if(ParametriDiScambio.getPiazza() == null) {
			System.out.println("Non sono stati inseriti Parametri di scambio");
			return;
		}
		System.out.println("\nParametri di scambio: ");
		System.out.println("Piazza: " + ParametriDiScambio.getPiazza()+";");
		System.out.print("Luogo: ");
		for(String luogo: ParametriDiScambio.getLuoghi())
			System.out.print(" " + luogo + ";");
		System.out.println();
		System.out.print("Giorni: ");
		for(GiorniDellaSettimana giorno: ParametriDiScambio.getGiorni())
			System.out.print(" " + giorno.getGiorno() + ";");
		System.out.println();
		System.out.print("Intervalli Orari: ");
		for(IntervalloOrario intervallo: ParametriDiScambio.getIntervalliOrari()) {
			String text = intervallo.toString().replace(',', ':');
			System.out.print(" " + text + ";  ");
		}
		System.out.println();
	}
	
	public static void visRoots() {
		if(GestioneGerarchie.getListaDiGerarchie() == null || GestioneGerarchie.getListaDiGerarchie().isEmpty()) {
			System.out.println("Non sono ancora state create gerarchie");
			return;
		}
		System.out.println("\nCategorie radice delle gerarchie: ");
		for(TreeNode<Categoria> albero : GestioneGerarchie.getListaDiGerarchie()) {
			System.out.println("Nome: " + albero.data.getNome() + ",  Descrizione: "+albero.data.getDescrizione()+";");
		}
	}
	
	public static Categoria sceltaFoglia() {
		if(GestioneGerarchie.getLeaves() == null || GestioneGerarchie.getLeaves().isEmpty()) {
			System.out.println("Non sono ancora state create gerarchie");
			return null;
		}
		System.out.println("\nScegli la categoria alla quale appartiene l'articolo: ");
		ArrayList<TreeNode<Categoria>> listaFoglie = GestioneGerarchie.getLeaves();
		for(int i=0; i< listaFoglie.size(); i++) {
			System.out.println(i+1 +") Nome: " + listaFoglie.get(i).data.getNome() + "  Descrizione: "+ listaFoglie.get(i).data.getDescrizione());
		}
		
		int scelta = InputDati.leggiIntero("Digita un numero: ", 1 , listaFoglie.size());
		
		return listaFoglie.get(scelta-1).data;
	}

}
