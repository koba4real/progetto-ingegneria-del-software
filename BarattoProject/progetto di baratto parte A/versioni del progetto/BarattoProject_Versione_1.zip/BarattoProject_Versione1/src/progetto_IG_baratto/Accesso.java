package progetto_IG_baratto;

import java.util.HashMap;

import utility.InputDati;

public class Accesso {
	private static Gruppo_Conf configuratori= new Gruppo_Conf();
	private static final String STRINGA_REGISTRAZIONE = " \nHai utilizzato le credenziali provvisorie!"
														+ "\nBenvenuto nell'area di registrazione, "
														+ "\nscegli le tue credenziali personali che utilizzerai negli accessi successivi:";
												
	public static void accedi() {
		
		String nomeUser = InputDati.leggiStringaNonVuota("\ninserisca il suo nome utente: ");
		String pass = InputDati.leggiStringaNonVuota("inserisca la sua password: ");
		Configuratore conf = new Configuratore (nomeUser, pass);
		
		if(checkSignIn(conf)) {			//checkSignIn � true se le credenziali inserite sono quelle predefinite
			registrati();
			GestioneGerarchie.inizializzaGerarchie();
		}
		else {
			boolean check  = configuratori.check_conf(conf);	//true se esistono le credenziali 
			if(check) {
				System.out.println("Benvenuto !!");
				GestioneGerarchie.inizializzaGerarchie();
			}
			else
				System.out.println("Credenziali non esistenti!");
		}
	}
	
	
	private static void registrati() {
		System.out.println(STRINGA_REGISTRAZIONE);
		String nomeUser;
		String pass ;
		boolean flag;
		boolean u_tooLong , p_tooLong;
		
		do {
			nomeUser = InputDati.leggiStringaNonVuota("\ninserisca il suo nome utente: ");
			u_tooLong= checkLength(nomeUser);
			
			pass =  InputDati.leggiStringa("inserisca la sua password: "); 
			p_tooLong= checkLength(pass);
			
			flag = configuratori.check_username(nomeUser);
			
			if(u_tooLong)
				System.out.println("ATTENZIONE! \nil username supera il numero massimo di caratteri!");
			if(p_tooLong)
				System.out.println("ATTENZIONE! \nla password supera il numero massimo di caratteri!");
			if(flag)
				System.out.println("ATTENZIONE! \nusername gi� esistente!");
	
		}while(flag || u_tooLong || p_tooLong);
		
		Configuratore conf = new Configuratore (nomeUser, pass);
		configuratori.aggiungiConf(conf);
		System.out.println("benvenuto!");
	}
	
	
	private static boolean checkLength(String l) {
		
		return l.length() >= 15;
	}
	
	private static boolean checkSignIn(Configuratore conf) {
		return (conf.getUsername().equals("user")) && (conf.getPassword().equals("A20M29O30")) ;
	}
	
	public static Gruppo_Conf getConfiguratori() {
		return configuratori;
	}

	public static void setConfiguratori(Gruppo_Conf configuratori) {
		Accesso.configuratori = configuratori;
	}	
	
	public static void setGruppo(HashMap<String, Configuratore> gruppo) {
		configuratori.setGruppo(gruppo);
	}
	
}
