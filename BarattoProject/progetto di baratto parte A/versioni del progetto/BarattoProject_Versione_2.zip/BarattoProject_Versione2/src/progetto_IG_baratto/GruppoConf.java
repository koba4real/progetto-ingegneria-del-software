package progetto_IG_baratto;

import java.util.HashMap;



public class GruppoConf {
	
	private HashMap gruppo = new HashMap<String , Configuratore>() ; 


	
	public HashMap getGruppo() {
		return gruppo;
	}

	public void setGruppo(HashMap gruppo) {
		this.gruppo = gruppo;
	}
	
	public void aggiungiConf(Configuratore conf) {
		String s = conf.getUsername();
		gruppo.put(s, conf);
	}
	
	public boolean check_username(String user) {	
		return gruppo.containsKey(user); // true se esiste gia il username nella hashmap
	}
	
	public boolean check_conf(Configuratore conf) {	 //true se esiste gi� il configuratore
		if( ! check_username(conf.getUsername()))
			return false;
		String u = conf.getUsername();
		String p = conf.getPassword();
		Configuratore c = (Configuratore)gruppo.get(u);
		return  c.getPassword().equals(p);
	}

	

	
}
