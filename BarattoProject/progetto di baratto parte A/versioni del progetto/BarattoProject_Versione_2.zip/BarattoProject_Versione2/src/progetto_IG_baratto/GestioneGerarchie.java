package progetto_IG_baratto;

import java.util.ArrayList;

import TreeNodeProject.TreeNode;

public class GestioneGerarchie {
	
	private static ArrayList<TreeNode<Categoria>> listaDiGerarchie = new ArrayList<>();

	public static ArrayList<TreeNode<Categoria>> getListaDiGerarchie() {
		return listaDiGerarchie;
	}
	
	public static void setListaDiGerarchie(ArrayList<TreeNode<Categoria>> lista) {
		listaDiGerarchie = lista ;
	}
	
	public static void addListaDiGerarchie(ArrayList<TreeNode<Categoria>> lista) {
		listaDiGerarchie.addAll(lista);
	}
	
	public static void addRoot(TreeNode<Categoria> root) {
		listaDiGerarchie.add(root);
	}
	
	public static ArrayList<TreeNode<Categoria>> getLeaves() {
		ArrayList<TreeNode<Categoria>> foglie = new ArrayList<TreeNode<Categoria>>();
		for(TreeNode<Categoria> gerarchia : listaDiGerarchie) {
			for (TreeNode<Categoria> node : gerarchia.getTreeRoot()) {
				if(node.isLeaf())
					foglie.add(node);
			}
		}
		return foglie;
	}
	
	public static void setLisataNomi() {	//modifica la lista dei nomi delle categorie radici 
		ArrayList<String> listaNomi = new ArrayList<String>();
		for(TreeNode<Categoria> nodo: listaDiGerarchie) {
			listaNomi.add( nodo.data.getNome() );
		}
		IOConfiguratore.setNomiRoot(listaNomi);	
	}
	

	
	
	
	
	
	

	
	
}
