package barattoModel;

import java.util.ArrayList;

public class ParametriDiScambio {
	
	private static String piazza;
	private static ArrayList<String> luoghi = new ArrayList<String>();
	private static ArrayList<GiorniDellaSettimana> giorni = new ArrayList<GiorniDellaSettimana>();
	private static ArrayList<IntervalloOrario> intervalliOrari = new ArrayList<IntervalloOrario>();
	private static int scadenza;
	private static int codiceIDOfferta = 0; 
	
	
	public static String getPiazza() {
		return piazza;
	}
	public static void setPiazza(String piazzaIn) {
		piazza = piazzaIn;
	}
	public static ArrayList<String> getLuoghi() {
		return luoghi;
	}
	public static void setLuoghi(ArrayList<String> luoghiIn) {
		luoghi = luoghiIn;
	}
	public static void addLuogo(String luogo) {
		luoghi.add(luogo);
	}
	public static ArrayList<GiorniDellaSettimana> getGiorni() {
		return giorni;
	}
	
	public static int getCodiceIDOfferta() {
		return codiceIDOfferta;
	}
	public static void setCodiceIDOfferta(int codiceIDOfferta) {
		ParametriDiScambio.codiceIDOfferta = codiceIDOfferta;
	}
	public static boolean checkGiorno(GiorniDellaSettimana giorno) {
		return giorni.contains(giorno);
	}
	
	public static void addGionrno(GiorniDellaSettimana giorno) {
		giorni.add(giorno);
	}
	public static ArrayList<IntervalloOrario> getIntervalliOrari() {
		return intervalliOrari;
	}
	public static void setIntervalliOrari(ArrayList<IntervalloOrario> intervalliOrariIn) {
		intervalliOrari = intervalliOrariIn;
	}
	public static void addIntervalloOrario(IntervalloOrario orario) {
		intervalliOrari.add(orario);
	}
	public static int getScadenza() {
		return scadenza;
	}
	public static void setScadenza(int scadenzaIn) {
		scadenza = scadenzaIn;
	}
	
	public static ArrayList<Object> getParamToSave(){
		ArrayList<Object> parToSave = new ArrayList<Object>();
		parToSave.add(piazza);
		parToSave.add(luoghi);
		parToSave.add(giorni);
		parToSave.add(intervalliOrari);
		parToSave.add(scadenza);
		parToSave.add(codiceIDOfferta);
		return parToSave;
	}
	
	public static void setParam(ArrayList<Object> paramSaved) {
		if(paramSaved==null||paramSaved.isEmpty())
			return;
		piazza = (String) paramSaved.get(0);
		luoghi = (ArrayList<String>)paramSaved.get(1);
		giorni = (ArrayList<GiorniDellaSettimana>) paramSaved.get(2);
		intervalliOrari = (ArrayList<IntervalloOrario>) paramSaved.get(3);
		scadenza = (int) paramSaved.get(4);
		if(paramSaved.size()>5)
			codiceIDOfferta = (int) paramSaved.get(5);
	}

	
}
