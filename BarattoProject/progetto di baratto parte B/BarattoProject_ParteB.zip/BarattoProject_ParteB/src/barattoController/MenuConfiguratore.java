package barattoController;

import java.util.ArrayList;

import barattoModel.Accesso;
import barattoModel.Categoria;
import barattoModel.GestioneGerarchie;
import barattoModel.Offerta;
import barattoModel.ParametriDiScambio;
import barattoModel.SaveData;
import barattoView.IOConfiguratore;
import barattoView.IOGeneric;
import barattoView.MyMenu;
import data.DataFacade;
import treeNodePackage.*;

public class MenuConfiguratore {
	
	private static final String STRING_VUOTA = "";
	private static final String CATEGORIA_ATTUALE = "Categoria attuale: ";
	private static final String CATEGORIA_RADICE = " (Categoria Radice)";
	private static final String TITOLO_MENU= "Menu Configuratori";
	private static final String[] VOCI1= { "Carica Dati da Input",
											"Inserisci una nuova gerarchia  ", 
											"visualizza gerarchie", 
											"Fissa il valore dei parametri di scambio",
											"Visualizza le Offerte aperte relative ad una categoria",
											"Visualizza le Offerte in scambio e le Offerte chiuse relative ad una categoria"};
	private static final String[] VOCI2= { "Inserisci una sottocategoria", "Torna alla categoria padre", "Visualizza albero"};
	
	public static void menuPrincipale() {
		MyMenu menu1 = new MyMenu(TITOLO_MENU ,VOCI1);
		int scelta ;
		do {
			scelta= menu1.scegli();
			switch(scelta) {
			case 1: 
				DataFacade.importFromInput();
				break;
			case 2:
				TreeNode<Categoria> rootCat = new TreeNode<>(IOConfiguratore.readCategoriaRadice(GestioneGerarchie.getRootNames()));
				rootCat = menuCategorie(rootCat);
				GestioneGerarchie.addRoot(rootCat);
				break;
			case 3:	//visualizza gerarchie
				if(GestioneGerarchie.getListaDiGerarchie().isEmpty())
					IOConfiguratore.listaGerarchieIsEmpty();
				else
					IOConfiguratore.visGerarchie(GestioneGerarchie.getListaDiGerarchie());
				break;
			case 4: //fissa i parametri di scambio
				if(ParametriDiScambio.getPiazza()==null)
					ParametriDiScambio.setParam(IOConfiguratore.readParametri());
				else
					IOConfiguratore.msgParametriFixed();
				break;
			case 5:
				ArrayList<Offerta> offerteAperte = new ArrayList<>();			
				Categoria cat = IOGeneric.sceltaFoglia(GestioneGerarchie.getLeaves());
				offerteAperte = Accesso.offerteAperte(cat);
				IOGeneric.visOfferteAperte(offerteAperte);
				break;
			case 6: 
				ArrayList<Offerta> offerteInScambio = new ArrayList<>();			
				Categoria categoria = IOGeneric.sceltaFoglia(GestioneGerarchie.getLeaves());
				offerteInScambio = Accesso.offerteInScambioEChiuse(categoria);
				IOGeneric.visOfferteInScambioEChiuse(offerteInScambio);
				break;
			case 0:
				break;
			}	
			
		}while(scelta!=0);	
		
	}
	
	private static TreeNode<Categoria> menuCategorie(TreeNode<Categoria> nodo) {
		MyMenu menu2 = new MyMenu(STRING_VUOTA ,VOCI2);
		int scelta ;
		do {
			String visRoot = STRING_VUOTA;
			if(nodo.isRoot())
				visRoot = CATEGORIA_RADICE;
			menu2.setTitolo(CATEGORIA_ATTUALE + nodo.data.getNome() + visRoot);
			
			scelta= menu2.scegli();
			switch(scelta) {
			case 1://inserisci una sottoCategoria		
				nodo = GestioneAlbero.inserisciSottocategoria(nodo);	
				break;
			case 2://ritorna al nodo padre 
				if( ! nodo.isRoot()) {
					nodo = nodo.parent;
				}
				else
					IOConfiguratore.msgNoParent();;
				break;
			case 3:	//visualizzazione gerarchia
					IOGeneric.visAlbero(nodo);
				break;
			case 0: 
				break;
			}
			
		}while(scelta!=0);	
		return nodo.getTreeRoot();
	}
	

}
