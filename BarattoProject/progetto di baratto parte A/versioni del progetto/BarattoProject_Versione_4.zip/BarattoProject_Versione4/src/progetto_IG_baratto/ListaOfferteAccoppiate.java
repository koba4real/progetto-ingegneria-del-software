package progetto_IG_baratto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

public class ListaOfferteAccoppiate implements Serializable {
	
	private static ArrayList<OfferteAccoppiate> listaOfferteAccoppiate = new ArrayList<>();

	public static ArrayList<OfferteAccoppiate> getListaOfferteAccoppiate() {
		return listaOfferteAccoppiate;
	}
	public static void setListaOfferteAccoppiate(ArrayList<OfferteAccoppiate> listaOfferteAccoppiate) {
		ListaOfferteAccoppiate.listaOfferteAccoppiate = listaOfferteAccoppiate;
	}
	
	public static void addOfferteAccoppiate(OfferteAccoppiate offerteAccoppiate) {
		listaOfferteAccoppiate.add(offerteAccoppiate);
	}
	
	public static ArrayList<Integer> offerteScadute() {
		ArrayList<Integer> idOfferteScadute = new ArrayList<>();
		
		Iterator<OfferteAccoppiate> it = listaOfferteAccoppiate.iterator();
		while (it.hasNext()) {
			OfferteAccoppiate offerte = it.next();
			if(offerte.checkScadenza()) {
				idOfferteScadute.add(offerte.getOffertaAccoppiata().getCoodiceID());
				idOfferteScadute.add(offerte.getOffertaSelezionata().getCoodiceID());
				it.remove();
			}	
		}
		return idOfferteScadute;
	}
	
	public static void setDataScadenzaOff(int id) {
		for(OfferteAccoppiate offerte : listaOfferteAccoppiate) {
			if(offerte.getOffertaAccoppiata().getCoodiceID() == id )
				offerte.setDataScadenza();
		}
	}
	
	public static OfferteAccoppiate getOfferteById(int id) {
		for(OfferteAccoppiate offerte: listaOfferteAccoppiate) {
			if(offerte.getOffertaAccoppiata().getCoodiceID()==id || offerte.getOffertaSelezionata().getCoodiceID()==id )
				return offerte;
		}
		return null;
	}
	
	public static void setLastFruitoreById(int id, String lastFruitore) {
		for(OfferteAccoppiate offerte: listaOfferteAccoppiate) {
			if(offerte.getOffertaAccoppiata().getCoodiceID()==id || offerte.getOffertaSelezionata().getCoodiceID()==id )
				 offerte.setlastFruitore(lastFruitore);
		}
	}
	public static void chiudiStatoById(int id) {
		for(OfferteAccoppiate offerte: listaOfferteAccoppiate) {
			if(offerte.getOffertaAccoppiata().getCoodiceID()==id || offerte.getOffertaSelezionata().getCoodiceID()==id )
				offerte.chiudiOff();
		}
	}
	public static void eliminaOfferte(OfferteAccoppiate off) {
		Iterator<OfferteAccoppiate> it = listaOfferteAccoppiate.iterator();
		while (it.hasNext()) {
			OfferteAccoppiate offerte = it.next();
				if(offerte.getOffertaAccoppiata().getCoodiceID()==off.getOffertaAccoppiata().getCoodiceID())
					it.remove();	
		}
	}
	
}
