package progetto_IG_baratto;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

public class OfferteAccoppiate implements Serializable{
	
	private Offerta offertaAccoppiata;
	private Offerta offertaSelezionata;
	private String luogoScabio;
	private LocalDate dataScambio;
	private double orarioScambio;
	private String lastFruitore ;		//fruitore che ha fissato l'ultimo appuntamento
	private Date dataDiScadenza;
	
	public OfferteAccoppiate(Offerta offertaAccoppiata, Offerta offertaSelezionata) {
		this.offertaAccoppiata = offertaAccoppiata;
		this.offertaSelezionata = offertaSelezionata;
		this.dataDiScadenza = getDataScadenza();
	}
	public Offerta getOffertaAccoppiata() {
		return offertaAccoppiata;
	}
	public void setOffertaAccoppiata(Offerta offertaAccoppiata) {
		this.offertaAccoppiata = offertaAccoppiata;
	}
	public Offerta getOffertaSelezionata() {
		return offertaSelezionata;
	}
	public void setOffertaSelezionata(Offerta offertaSelezionata) {
		this.offertaSelezionata = offertaSelezionata;
	}
	public String getLuogoScabio() {
		return luogoScabio;
	}
	public void setLuogoScabio(String luogoScabio) {
		this.luogoScabio = luogoScabio;
	}
	public LocalDate getDataScambio() {
		return dataScambio;
	}
	public void setDataScambio(LocalDate dataScambio) {
		this.dataScambio = dataScambio;
	}
	public double getOrarioScambio() {
		return orarioScambio;
	}
	public void setOrarioScambio(double orarioScambio) {
		this.orarioScambio = orarioScambio;
	}
	public String getlastFruitore() {
		return lastFruitore;
	}
	public void setlastFruitore(String lastFruitore) {
		this.lastFruitore = lastFruitore;
	}
	public boolean checkScadenza() {		//ritorna true se � superata la scadenza
		Calendar calendar = Calendar.getInstance();
		Date oggi = calendar.getTime();
		return oggi.compareTo(dataDiScadenza)>0 ;
	}
	public void setDataScadenza() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_MONTH, ParametriDiScambio.getScadenza());
		this.dataDiScadenza = calendar.getTime();
	}
	private Date getDataScadenza() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_MONTH, ParametriDiScambio.getScadenza());
		return calendar.getTime();
	}
	
	public void chiudiOff() {
		this.offertaAccoppiata.setStatoOfferta(StatoOfferta.CHIUSA);
		this.offertaSelezionata.setStatoOfferta(StatoOfferta.CHIUSA);
	}
	
	public String toString() {
		return "[ Luogo: " + this.luogoScabio + ", Data:  " + this.dataScambio.toString() +", Orario: "+ String.format("% .2f", this.orarioScambio)+"]";
	}

}
