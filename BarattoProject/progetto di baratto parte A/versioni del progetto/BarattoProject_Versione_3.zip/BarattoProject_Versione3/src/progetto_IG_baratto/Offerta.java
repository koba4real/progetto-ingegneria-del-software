package progetto_IG_baratto;

import java.io.Serializable;

public class Offerta implements Serializable {
	
	private Articolo articolo;
	private boolean offertaAperta;
	private int passaggiDiStato;
	
	public Offerta(Articolo articolo) {
		this.articolo = articolo;
		this.offertaAperta = true;
		this.passaggiDiStato = 0;
	}
	public Articolo getArticolo() {
		return articolo;
	}
	public void setArticolo(Articolo articolo) {
		this.articolo = articolo;
	}
	public boolean isOffertaAperta() {
		return offertaAperta;
	}
	public void apriOfferta() {
		this.passaggiDiStato++;
		this.offertaAperta = true;
	}
	public void ritiraOfferta() {
		this.passaggiDiStato++;
		this.offertaAperta = false;
	}
	public int getPassaggiDiStato() {
		return passaggiDiStato;
	}
	public String toString() {
		return this.articolo.toString();
	}
}
