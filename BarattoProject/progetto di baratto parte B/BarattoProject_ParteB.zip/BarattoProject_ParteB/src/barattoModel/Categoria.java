package barattoModel;

import java.io.Serializable;
import java.util.ArrayList;

public class Categoria implements Serializable{
	
	private String nome;
	private String descrizione;
	private ArrayList<CampoNativo> campi = new ArrayList<CampoNativo>();
	
	public Categoria() {}
	public Categoria(String nome, String descrizione) {
		this.nome = nome;
		this.descrizione = descrizione;
	}
	
	public void addCampo(CampoNativo campo) {
		campi.add(campo);
	}
	
	
	public void addCampi(ArrayList<CampoNativo> campo) {
		campi.addAll(campo);
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDescrizione() {
		return descrizione;
	}
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	public ArrayList<CampoNativo> getCampi() {
		return campi;
	}
	public void setCampi(ArrayList<CampoNativo> campiNativi) {
		this.campi = campiNativi;
	}
	
	public String toString() {
		return "Nome: " + this.nome + ";  Descrizione: " +this.descrizione + ";  Campi nativi: "  ;
	}
	public Categoria getCopy() {
		Categoria copia = new Categoria(this.nome, this.descrizione);
		ArrayList<CampoNativo> copiaCampi= new ArrayList<>();
		for(CampoNativo campo: this.campi) {
			copiaCampi.add(new CampoNativo(campo.getNome(), campo.isOblligatorio()));
		}
		copia.addCampi(copiaCampi);
		return copia;
	}	
	
	
}
