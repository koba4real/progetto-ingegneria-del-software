package progetto_IG_baratto;

import java.util.HashMap;

import utility.InputDati;

public class Accesso {
	private static GruppoConf configuratori= new GruppoConf();
	private static GruppoFruitori fruitori = new GruppoFruitori(); 
	private static final String STRINGA_CONF = "\nHai utilizzato le credenziali provvisorie!";
	private static final String STRINGA_REGISTRAZIONE = "\nBenvenuto nell'area di registrazione, "
															+ "\nscegli le tue credenziali personali che utilizzerai negli accessi successivi:";
												
	public static void accedi() {
		
		String nomeUser = InputDati.leggiStringaNonVuota("\ninserisca il suo nome utente: ");
		String pass = InputDati.leggiStringaNonVuota("inserisci la tua password: ");
	
		Configuratore conf = new Configuratore (nomeUser, pass);
		Fruitore fruitore = new Fruitore(nomeUser, pass);
		
		if(checkDefaultCred(conf)) {			//checkSignIn � true se le credenziali inserite sono quelle predefinite
			registrati(true);
			MenuConfiguratore.menuPrincipale();
			return;
		}
	
		boolean checkConf  = configuratori.check_conf(conf);	//true se esistono le credenziali 
		boolean checkFruitore = fruitori.check_fruitore(fruitore);	
		
		if(checkConf) {
			System.out.println("Benvenuto "+conf.getUsername()+"!");
			MenuConfiguratore.menuPrincipale();
		}
		else if(checkFruitore) {
			System.out.println("Benvenuto "+fruitore.getUsername()+"!");
			MenuFruitore.printMenu();
		}
		else
			System.out.println("Credenziali non esistenti!");
	}
	
	
	public static void registrati(boolean isConf) {
		if(isConf)
			System.out.println(STRINGA_CONF);
		System.out.println(STRINGA_REGISTRAZIONE);

		String nomeUser;
		String pass ;
		boolean flag;
		boolean u_tooLong , p_tooLong;
		
		do {
			nomeUser = InputDati.leggiStringaNonVuota("\ninserisca il nome utente: ");
			u_tooLong= checkLength(nomeUser);
			
			pass =  InputDati.leggiStringa("inserisca la password: "); 
			p_tooLong= checkLength(pass);
			
			flag = isConf ? configuratori.check_username(nomeUser) :  fruitori.check_username(nomeUser);
			flag = flag ? true : configuratori.check_username(nomeUser) ;
			
			if(u_tooLong)
				System.out.println("ATTENZIONE! \nil username supera il numero massimo di caratteri!");
			if(p_tooLong)
				System.out.println("ATTENZIONE! \nla password supera il numero massimo di caratteri!");
			if(flag)
				System.out.println("ATTENZIONE! \nusername gi� esistente!");
	
		}while(flag || u_tooLong || p_tooLong);
		
		if(isConf) {
			Configuratore conf = new Configuratore (nomeUser, pass);
			configuratori.aggiungiConf(conf);
		}
		else{
			Fruitore fruitore = new Fruitore (nomeUser, pass);
			fruitori.aggiungiFruitore(fruitore);	
		}
		
		
		System.out.println("benvenuto!");
		if(!isConf)
			MenuFruitore.printMenu();
	}
	
	
	private static boolean checkLength(String l) {
		
		return l.length() >= 15;
	}
	
	private static boolean checkDefaultCred(Configuratore conf) {
		return (conf.getUsername().equals("user")) && (conf.getPassword().equals("A20M29O30")) ;
	}
	
	public static GruppoConf getConfiguratori() {
		return configuratori;
	}

	public static void setConfiguratori(GruppoConf configuratori) {
		Accesso.configuratori = configuratori;
	}
	
	public static GruppoFruitori getFruitori() {
		return fruitori;
	}
	
	public static void setFruitori(GruppoFruitori fruitori) {
		Accesso.fruitori = fruitori;
	}

	public static void setGruppoConf(HashMap<String, Configuratore> gruppo) {
		configuratori.setGruppo(gruppo);
	}
	public static void setGruppoFruitore(HashMap<String, Fruitore> gruppo) {
		fruitori.setGruppo(gruppo);
	}
	
	
}
