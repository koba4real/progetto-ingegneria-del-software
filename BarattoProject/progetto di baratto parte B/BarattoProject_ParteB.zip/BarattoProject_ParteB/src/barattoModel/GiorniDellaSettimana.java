package barattoModel;

import java.io.Serializable;

public enum GiorniDellaSettimana implements Serializable{

	LUNEDI("lunedi"),
	MARTEDI("martedi"),
	MERCOLEDI("mercoledi"),
	GIOVEDI("giovedi"),
	VENERDI("venerdi"),
	SABATO("sabato"),
	DOMENICA("domenica");
	
	private String giorno;
	
	GiorniDellaSettimana(String giorno) {
		this.giorno=giorno;
	}
	
	public String getGiorno() {
		return this.giorno;
	}
	
}
