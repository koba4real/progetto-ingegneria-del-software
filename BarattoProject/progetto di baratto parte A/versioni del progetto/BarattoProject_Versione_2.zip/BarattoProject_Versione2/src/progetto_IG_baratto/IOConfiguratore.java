package progetto_IG_baratto;

import java.util.ArrayList;

import TreeNodeProject.TreeNode;
import utility.InputDati;

public class IOConfiguratore {
	
	private static ArrayList<String> nomiRootCat = new ArrayList<String>();	
	
	public static Categoria readCategoriaRadice() {
		
		String 	nome = InputDati.leggiStringaNonVuota("Inserisci il nome della Categoria Radice: ");	
		
		while( checkRootName(nome) ){	
			System.out.println("Attenzione! il nome della categoria radice � gia esistente");
			nome = InputDati.leggiStringaNonVuota("Inserisci il nome della Categoria Radice: ");	
		};
		
		nomiRootCat.add(nome);
		
		String descrizione = InputDati.leggiStringaNonVuota("Inserisci la descrizione della categoria "+nome + ": ");
		CampoNativo campoStato = new CampoNativo("Stato di conservazione", true);
		CampoNativo campoDesc = new CampoNativo("Descrizione libera", false);
		Categoria rootCat = new Categoria(nome, descrizione);
		rootCat.addCampo(campoStato);
		rootCat.addCampo(campoDesc);
		
		rootCat.addCampi(readCampi(rootCat));//controllo che nomi dei campi aggiunti non sia uguale ai campi di default
		return rootCat;
	}

	public static Categoria readCategoria() {
		String nome = InputDati.leggiStringaNonVuota("Inserisci il nome della Categoria: ");
		String descrizione = InputDati.leggiStringaNonVuota("Inserisci Descrizione: ");
		Categoria categoria = new Categoria(nome, descrizione);
		return categoria;
	}
	
	public static void  readParametri() {
		ParametriDiScambio.setPiazza(InputDati.leggiStringaNonVuota("Inserisci la Piazza in cui avvengono gli scambi: "));
		ParametriDiScambio.setLuoghi(readLuoghi());
		readDays();
		ParametriDiScambio.setIntervalliOrari(readIntervalli());
		ParametriDiScambio.setScadenza(InputDati.leggiInteroNonNegativo("Inserisci la scadenza per accettare la proposta di scambio (numero di giorni): "));
		
	}
	
	private static ArrayList<String> readLuoghi() {
		ArrayList<String> luoghi = new ArrayList<String>();
		do{
			luoghi.add(InputDati.leggiStringaNonVuota("Inserisci il luogo in cui tali scambi avvengono: "));
		}while(InputDati.yesOrNo("vuoi inserire altri luoghi? "));
		return luoghi;
	}

	private static ArrayList<IntervalloOrario> readIntervalli() {
		ArrayList<IntervalloOrario> intervalli = new ArrayList<IntervalloOrario>();
		do {
			System.out.println("inserisci l'intervallo orario in cui possono avvenire gli scambi");
			double orarioI = InputDati.leggiDouble("orario inizio: ");
			
			while( ! IntervalloOrario.checkOrario(orarioI)) {
				System.out.println("Attenzione l'orario inserito � errato, riprovi");
				orarioI = InputDati.leggiDouble("orario inizio: ");
			}
			double orarioF = InputDati.leggiDouble("orario fine: ");
			
			while( ! IntervalloOrario.checkOrario(orarioF)) {
				System.out.println("Attenzione l'orario inserito � errato, riprovi");
				orarioF = InputDati.leggiDouble("orario fine: ");
			}
			
			IntervalloOrario intervallo = new IntervalloOrario(orarioI, orarioF);
			intervalli.add(intervallo);

		}while(InputDati.yesOrNo("vuoi inserire altri intervalli orari?"));
		return intervalli;
	}

	public static Categoria setCampi(Categoria cat) {
		cat.addCampi(readCampi(cat));
		return cat;
	}
	
	public static void listaGerarchieIsEmpty() {
		System.out.println("Attenzione non sono state create gerarchie!");
	}
	
	public static void msgNoParent() {
		System.out.println("Attenzione la categoria radice non ha una categoria padre");
	}
	
	private static void readDays() {
		boolean resta ;
		do {
			resta = false;
			String scelta = InputDati.leggiStringaNonVuota("inserisci il giorno in cui possono avere luogo gli scambi: ");
			switch(scelta.toLowerCase()) {
				case "lunedi" :
					if( ParametriDiScambio.checkGiorno(GiorniDellaSettimana.LUNEDI)) {
						msgDayInserito();
						break;
					}
					ParametriDiScambio.addGionrno(GiorniDellaSettimana.LUNEDI);
					break;
				case "martedi" :
					if( ParametriDiScambio.checkGiorno(GiorniDellaSettimana.MARTEDI)) {
						msgDayInserito();
						break;
					}
					ParametriDiScambio.addGionrno(GiorniDellaSettimana.MARTEDI);
					break;
				case "mercoledi" :
					if( ParametriDiScambio.checkGiorno(GiorniDellaSettimana.MERCOLEDI)) {
						msgDayInserito();
						break;
					}
					ParametriDiScambio.addGionrno(GiorniDellaSettimana.MERCOLEDI);
					break;
				case "giovedi" :
					if( ParametriDiScambio.checkGiorno(GiorniDellaSettimana.GIOVEDI)) {
						msgDayInserito();
						break;
					}
					ParametriDiScambio.addGionrno(GiorniDellaSettimana.GIOVEDI);
					break;
				case "venerdi" :
					if( ParametriDiScambio.checkGiorno(GiorniDellaSettimana.VENERDI)) {
						msgDayInserito();
						break;
					}
					ParametriDiScambio.addGionrno(GiorniDellaSettimana.VENERDI);
					break;
				case "sabato" :
					if( ParametriDiScambio.checkGiorno(GiorniDellaSettimana.SABATO)) {
						msgDayInserito();
						break;
					}
					ParametriDiScambio.addGionrno(GiorniDellaSettimana.SABATO);
					break;
				case "domenica" :
					if( ParametriDiScambio.checkGiorno(GiorniDellaSettimana.DOMENICA)) {
						msgDayInserito();
						break;
					}
					ParametriDiScambio.addGionrno(GiorniDellaSettimana.DOMENICA);
					break;
				default:
					System.out.println("il giorno che hai inserito non � esistente!");
					resta= true;
					break;
			}
			
		}while(resta || InputDati.yesOrNo("vuoi inserire altri giorni? "));
	}
	
	private static void msgDayInserito() {
		System.out.println("ATTENZIONE hai gia inserito questo giorno");
	}
	
	private static boolean checkRootName(String nome) {
		
		for(String nomeLista: nomiRootCat) {
			 if( nomeLista.equalsIgnoreCase(nome)) 
				 return true;
		}
		return false;	
	}

	public static void visGerarchie() {
		System.out.println("Gerarchie salvate: \n");
		for(TreeNode<Categoria> albero : GestioneGerarchie.getListaDiGerarchie()) {
			GestioneAlbero.visAlbero(albero);
			System.out.println("\n");
		}
	}
	
	private static ArrayList<CampoNativo> readCampi(Categoria cat) {
		
		ArrayList<CampoNativo> campiNativi = new ArrayList<CampoNativo>();
		
		while( InputDati.yesOrNo("vuoi inserire campi nativi? ") ) {		//attenzione se non aggiunge nulla hai array null
			
			String nome = InputDati.leggiStringaNonVuota("Inserisci il nome del campo nativo:");
			
			while( checkNomeCampi(nome, cat) ){
				System.out.println("ATTENZIONE! il nome del campo inserito � gi� esistente!");
				nome = InputDati.leggiStringaNonVuota("Inserisci il nome del campo nativo:");	
			}	
			
			boolean obbligatorio = InputDati.yesOrNo("questo campo nativo � obbligatori? ");
			campiNativi.add(new CampoNativo(nome, obbligatorio));
		}
		
		return campiNativi;
	}
	
	private static boolean checkNomeCampi(String nome, Categoria cat) {
		for(CampoNativo c : cat.getCampi()) {
			if(c.getNome().equalsIgnoreCase(nome))
				return true;
		}
		return false;
	}

	public static void setNomiRoot (ArrayList<String> nomi) {
		nomiRootCat = nomi;
	}
	
}
