package barattoModel;

import java.util.HashMap;

public class GruppoFruitori extends GruppoUtente{
	
	public GruppoFruitori() {
		this.gruppo = new HashMap<String , Fruitore>() ;
	}
	
	public void aggiungiFruitore(Fruitore fruitore) {
		String s = fruitore.getUsername();
		this.gruppo.put(s.toLowerCase(), fruitore);
	}
	
	public void setFruitore(Fruitore fruitore) {
		this.gruppo.put(fruitore.getUsername(), fruitore);
	}
	
	public Fruitore getFruitore(String nome) {
		return (Fruitore) this.gruppo.get(nome);
	}
	
	public boolean checkUser(Utente user) {	 //true se esiste gi� il Fruitore
		if( ! check_username(user.getUsername()))
			return false;
		String u = user.getUsername();
		String p = user.getPassword();
		Fruitore c = (Fruitore)this.gruppo.get(u);
		return  c.getPassword().equals(p);
	}

}
