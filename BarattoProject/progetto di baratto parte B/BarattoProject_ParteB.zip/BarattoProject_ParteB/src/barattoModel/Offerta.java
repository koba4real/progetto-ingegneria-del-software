package barattoModel;

import java.io.Serializable;
import java.util.Date;
import java.util.Calendar;

public class Offerta implements Serializable {
	
	private Articolo articolo;
	private String autoreOfferta;
	private int coodiceID;
	private int passaggiDiStato;
	private StatoOfferta statoOfferta;
	private Date dataDiAccoppiamento;
	
	
	
	public Offerta(Articolo articolo, String autoreOfferta) {
		this.articolo = articolo;
		this.autoreOfferta = autoreOfferta;
		this.passaggiDiStato = 0;
		this.statoOfferta = StatoOfferta.APERTA;
		this.coodiceID = ParametriDiScambio.getCodiceIDOfferta()+1;
		ParametriDiScambio.setCodiceIDOfferta(coodiceID);
	}
	public Articolo getArticolo() {
		return articolo;
	}
	public void setArticolo(Articolo articolo) {
		this.articolo = articolo;
	}
	public boolean isOffertaAperta() {
		return statoOfferta.getStato().equalsIgnoreCase("aperta");
	}
	public int getPassaggiDiStato() {
		return passaggiDiStato;
	}
	public StatoOfferta getStatoOfferta() {
		return statoOfferta;
	}
	public void setStatoOfferta(StatoOfferta stato) {
		this.statoOfferta=stato;
	}
	public String getAutoreOfferta() {
		return autoreOfferta;
	}
	public void setAutoreOfferta(String autoreOfferta) {
		this.autoreOfferta = autoreOfferta;
	}
	public Date getDataDiAccoppiamento() {
		return dataDiAccoppiamento;
	}
	public void setDataDiAccoppiamento(Date dataDiAccoppiamento) {
		this.dataDiAccoppiamento = dataDiAccoppiamento;
	}
	public int getCoodiceID() {
		return coodiceID;
	}
	public void setCoodiceID(int coodiceID) {
		this.coodiceID = coodiceID;
	}
	public String toString() {
		return this.articolo.toString() + "(Offerta " + this.statoOfferta.getStato() +")";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + coodiceID;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Offerta other = (Offerta) obj;
		if (coodiceID != other.coodiceID)
			return false;
		return true;
	}
	
}
