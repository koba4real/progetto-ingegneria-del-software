package progetto_IG_baratto;

import utility.MyMenu;

public class BarattoMain {
		private static final String TITOLO_MENU= "MENU BARATTO";
		private static final String TITOLO= "\nBENVENUTO NELL APP DI BARATTO\n";
		private static final String[] VOCI= { "Accedi ", "Salva i dati\n\n----------------------------------------------",
																		"Sei un nuovo Fruitore? Registrati qui "
																	  +"\n----------------------------------------------"};
		
	public static void main(String[] args){
		
			System.out.println(TITOLO);
			SaveData.load_mapp();//controllare se null
			MyMenu menu = new MyMenu(TITOLO_MENU ,VOCI);
			int scelta ;
			do {
				scelta= menu.scegli();
				switch(scelta) {
				case 1:
					Accesso.accedi();
					break;
				case 2:
					SaveData.save();
					break;
				case 3:
					Accesso.registrati(false);
					break;
				case 0:
					break;
				}
				
			}while(scelta!=0);
			System.out.println("ARRIVEDERCI");
		}
	}


