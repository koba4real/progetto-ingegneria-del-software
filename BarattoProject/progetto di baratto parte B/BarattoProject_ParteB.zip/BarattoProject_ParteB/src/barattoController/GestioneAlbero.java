package barattoController;
import barattoModel.Categoria;
import barattoView.IOConfiguratore;
import treeNodePackage.TreeNode;

public class GestioneAlbero {	//classe di appoggio al MenuConfiguratore
	
	public static TreeNode<Categoria> inserisciSottocategoria(TreeNode<Categoria> nodo) {
		Categoria cat = IOConfiguratore.readCategoria();
		while( checkNameCat(cat.getNome(), nodo) ){
			IOConfiguratore.msgNomeCatPresente();
			cat = IOConfiguratore.readCategoria();
		}
		
		TreeNode<Categoria> nodoFiglio = nodo.addChild(cat) ;
		nodoFiglio.data.addCampi(nodo.data.getCampi());
		nodoFiglio.data.setCampi(IOConfiguratore.setCampi(cat).getCampi());
		
		return nodoFiglio;	
	}	
	private static boolean checkNameCat(String nome, TreeNode<Categoria> nodo) {
		TreeNode<Categoria> rootNode = nodo.getTreeRoot();
		for (TreeNode<Categoria> node : rootNode ) {
			if( node.data.getNome().equalsIgnoreCase(nome) )
				return true;
		}
		return false;
	}	
}
